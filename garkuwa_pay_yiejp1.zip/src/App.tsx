/**
 * Garkuwa Pay — Main App
 *
 * Non-custodial, gasless USDC wallet for viral sharing via Facebook Messenger.
 *
 * Architecture:
 *  - Circle Modular Wallets (ERC-4337 MSCA) with passkey authentication
 *  - Safe-Mode guard: USDC-only, $50/day cap, biometric re-auth gate at $20
 *  - Escrow claim links with OG metadata for Messenger rich cards
 *  - Utility payments (airtime, data, bills) via Reloadly integration points
 *
 * See docs/architecture.md for the full system design.
 */

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { LogOut, Settings, Wallet } from 'lucide-react'
import { useAccount, useDisconnect } from 'wagmi'

// Hooks
import { usePasskeyWallet } from '@/hooks/usePasskeyWallet'
import { useUsdcBalance } from '@/hooks/useUsdcBalance'
import { useSafeSend } from '@/hooks/useSafeSend'
import { useExternalSend } from '@/hooks/useExternalSend'
import { useClaimLink } from '@/hooks/useClaimLink'

// Components
import { AuthGate } from '@/components/AuthGate'
import { HeroBalance } from '@/components/HeroBalance'
import { ActionRow } from '@/components/ActionRow'
import { SendSheet } from '@/components/SendSheet'
import { ClaimSheet } from '@/components/ClaimSheet'
import { ShareSheet } from '@/components/ShareSheet'
import { UtilityPanel } from '@/components/UtilityPanel'

type ActiveSheet = 'send' | 'claim' | 'share' | 'utility' | null
type WalletMode = 'passkey' | 'external'

export default function App() {
  const wallet = usePasskeyWallet()
  const { address: externalAddress, isConnected } = useAccount()
  const { disconnect } = useDisconnect()
  const [walletMode, setWalletMode] = useState<WalletMode>('passkey')

  // Active address: passkey wallet or external wallet
  const activeAddress = walletMode === 'external' && isConnected
    ? (externalAddress ?? null)
    : wallet.accountAddress

  const balance = useUsdcBalance(activeAddress)
  const passkeySender = useSafeSend(wallet)
  const externalSender = useExternalSend()
  const sender = walletMode === 'external' ? externalSender : passkeySender
  const claimState = useClaimLink(wallet)
  const [activeSheet, setActiveSheet] = useState<ActiveSheet>(null)

  const isPasskeyAuth = wallet.authState.status === 'authenticated'
  const isExternalAuth = walletMode === 'external' && isConnected
  const isAuthenticated = isPasskeyAuth || isExternalAuth

  const displayName = walletMode === 'external'
    ? (externalAddress ? `${externalAddress.slice(0, 6)}…${externalAddress.slice(-4)}` : 'External Wallet')
    : wallet.displayName

  const handleLogout = () => {
    if (walletMode === 'external') {
      disconnect()
      setWalletMode('passkey')
    } else {
      wallet.logout()
    }
  }

  // ── Not authenticated: show the auth gate ───────────────────────────────
  if (!isAuthenticated) {
    return (
      <AuthGate
        wallet={wallet}
        onExternalWalletConnected={() => setWalletMode('external')}
        isExternalConnected={isConnected}
      />
    )
  }

  // ── Authenticated: wallet shell ──────────────────────────────────────────
  return (
    <div
      className="relative min-h-dvh overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #f9f9fc 0%, #fffcf7 52%, #fbf7f2 100%)' }}
    >
      {/* Background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div style={{ position: 'absolute', top: '8%', left: '5%', width: 280, height: 280, borderRadius: '50%', background: 'radial-gradient(circle, rgba(133,177,237,0.22) 0%, transparent 70%)', filter: 'blur(60px)' }} />
        <div style={{ position: 'absolute', bottom: '8%', right: '8%', width: 260, height: 260, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,205,131,0.20) 0%, transparent 70%)', filter: 'blur(58px)' }} />
      </div>

      <div className="relative z-10 mx-auto max-w-md px-4 pb-10 pt-6">
        {/* Header */}
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className="flex size-8 items-center justify-center rounded-xl"
              style={{ background: 'var(--accent)' }}
            >
              <span className="display text-sm font-bold text-white">$</span>
            </div>
            <span className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>Garkuwa Pay</span>
          </div>

          <div className="flex items-center gap-2">
            {/* External wallet badge */}
            {walletMode === 'external' && (
              <span className="flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium"
                style={{ background: 'rgba(18,45,69,0.08)', color: 'var(--ink-2)' }}>
                <Wallet className="size-3" />
                External
              </span>
            )}

            {/* Pending claim badge */}
            {claimState.pendingClaim && (
              <motion.button
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                onClick={() => setActiveSheet('claim')}
                className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold text-white"
                style={{ background: 'var(--danger)' }}
              >
                <span>Claim ${claimState.pendingClaim.amountUsdc}</span>
              </motion.button>
            )}

            <button
              className="rounded-full p-2 transition hover:opacity-60"
              style={{ background: 'rgba(18,45,69,0.06)' }}
              aria-label="Settings"
            >
              <Settings className="size-4" style={{ color: 'var(--ink-2)' }} />
            </button>

            <button
              onClick={handleLogout}
              className="rounded-full p-2 transition hover:opacity-60"
              style={{ background: 'rgba(18,45,69,0.06)' }}
              aria-label="Sign out"
            >
              <LogOut className="size-4" style={{ color: 'var(--ink-2)' }} />
            </button>
          </div>
        </header>

        {/* Main content */}
        <main className="space-y-4">
          {/* Hero balance card */}
          <AnimatePresence mode="wait">
            <motion.div
              key={wallet.accountAddress ?? 'loading'}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            >
              <HeroBalance
                balance={balance}
                address={activeAddress ?? ''}
                displayName={displayName}
              />
            </motion.div>
          </AnimatePresence>

          {/* Action row */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.07, ease: [0.22, 1, 0.36, 1] }}
          >
            <ActionRow
              onSend={() => setActiveSheet('send')}
              onClaim={() => setActiveSheet('claim')}
              onShare={() => setActiveSheet('share')}
              onUtility={() => setActiveSheet('utility')}
              hasPendingClaim={!!claimState.pendingClaim}
            />
          </motion.div>

          {/* Activity placeholder */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.14, ease: [0.22, 1, 0.36, 1] }}
            className="rounded-3xl p-5"
            style={{
              background: 'rgba(255,255,255,0.64)',
              backdropFilter: 'blur(24px) saturate(180%)',
              WebkitBackdropFilter: 'blur(24px) saturate(180%)',
              border: '1px solid rgba(255,255,255,0.68)',
              boxShadow: '0 8px 32px rgba(18,45,69,0.08)',
            }}
          >
            <p className="mb-3 text-xs font-semibold" style={{ color: 'var(--muted)' }}>
              RECENT ACTIVITY
            </p>
            <div className="space-y-2">
              {[
                { label: 'Zero gas fees on Arc Testnet', sub: 'Sponsored by Circle Gas Station' },
                { label: 'Safe Mode active', sub: 'USDC transfers only · $50/day limit' },
                { label: 'Biometric auth enabled', sub: 'Re-auth required above $20' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between rounded-xl px-3 py-2.5" style={{ background: 'rgba(18,45,69,0.04)' }}>
                  <div>
                    <p className="text-xs font-medium" style={{ color: 'var(--ink)' }}>{item.label}</p>
                    <p className="text-xs" style={{ color: 'var(--subtle)' }}>{item.sub}</p>
                  </div>
                  <div className="size-2 rounded-full" style={{ background: 'var(--success)' }} />
                </div>
              ))}
            </div>

            <p className="mt-3 text-xs" style={{ color: 'var(--subtle)' }}>
              Transaction history will appear here after your first send or claim.
            </p>
          </motion.div>

          {/* Testnet notice */}
          <p className="text-center text-xs" style={{ color: 'var(--subtle)' }}>
            Arc Testnet · Get test USDC from the sidebar faucet
          </p>
        </main>
      </div>

      {/* Bottom sheets */}
      <SendSheet
        open={activeSheet === 'send'}
        onClose={() => setActiveSheet(null)}
        sender={sender}
        balance={balance.formatted}
      />
      <ClaimSheet
        open={activeSheet === 'claim'}
        onClose={() => setActiveSheet(null)}
        claimState={claimState}
      />
      <ShareSheet
        open={activeSheet === 'share'}
        onClose={() => setActiveSheet(null)}
        claimState={claimState}
        displayName={wallet.displayName}
      />
      <UtilityPanel
        open={activeSheet === 'utility'}
        onClose={() => setActiveSheet(null)}
        balance={balance.formatted}
      />
    </div>
  )
}
