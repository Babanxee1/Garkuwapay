/**
 * TxStatus
 *
 * Inline transaction state component — renders states from real domain hooks.
 * Never simulates progress.
 */

import { Loader2, CheckCircle2, XCircle, ExternalLink, Fingerprint } from 'lucide-react'
import type { TxState } from '@/types/wallet'

const glass = {
  inner: {
    background: 'rgba(255,255,255,0.46)',
    border: '1px solid rgba(255,255,255,0.56)',
  } as React.CSSProperties,
}

interface Props {
  state: TxState
  onReset?: () => void
}

export function TxStatus({ state, onReset }: Props) {
  if (state.stage === 'idle') return null

  return (
    <div className="rounded-2xl p-4" style={glass.inner}>
      {state.stage === 'biometric' && (
        <div className="flex items-center gap-3">
          <Fingerprint className="size-5 shrink-0 animate-pulse" style={{ color: 'var(--accent)' }} />
          <div>
            <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Biometric check</p>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>Touch ID or Face ID required for transfers above $20</p>
          </div>
        </div>
      )}

      {state.stage === 'signing' && (
        <div className="flex items-center gap-3">
          <Loader2 className="size-5 shrink-0 animate-spin" style={{ color: 'var(--accent)' }} />
          <div>
            <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Signing transaction</p>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>No gas fee — sponsored by Circle Gas Station</p>
          </div>
        </div>
      )}

      {state.stage === 'confirming' && (
        <div className="flex items-center gap-3">
          <Loader2 className="size-5 shrink-0 animate-spin" style={{ color: 'var(--accent)' }} />
          <div>
            <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Confirming on Arc</p>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>Usually a few seconds</p>
          </div>
        </div>
      )}

      {state.stage === 'success' && (
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="size-5 shrink-0" style={{ color: 'var(--success)' }} />
            <p className="text-sm font-semibold" style={{ color: 'var(--success)' }}>Confirmed</p>
          </div>
          {state.explorerUrl && (
            <a
              href={state.explorerUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-xs"
              style={{ color: 'var(--accent-hover)' }}
            >
              View on explorer <ExternalLink className="size-3" />
            </a>
          )}
          {onReset && (
            <button
              onClick={onReset}
              className="text-xs font-medium"
              style={{ color: 'var(--muted)' }}
            >
              Send another
            </button>
          )}
        </div>
      )}

      {state.stage === 'error' && (
        <div className="space-y-2">
          <div className="flex items-start gap-3">
            <XCircle className="mt-0.5 size-5 shrink-0" style={{ color: 'var(--danger)' }} />
            <div>
              <p className="text-sm font-semibold" style={{ color: 'var(--danger)' }}>Transaction failed</p>
              <p className="mt-0.5 text-xs" style={{ color: 'var(--muted)' }}>{state.errorMessage}</p>
            </div>
          </div>
          {onReset && (
            <button
              onClick={onReset}
              className="text-xs font-medium"
              style={{ color: 'var(--accent-hover)' }}
            >
              Try again
            </button>
          )}
        </div>
      )}
    </div>
  )
}
