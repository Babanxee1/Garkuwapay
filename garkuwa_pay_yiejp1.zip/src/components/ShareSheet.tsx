/**
 * ShareSheet
 *
 * Create a USDC claim link and share it to Facebook Messenger.
 * Includes OG preview card showing what the recipient sees in Messenger.
 */

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Share2, Copy, Check, MessageCircle, Loader2, ExternalLink } from 'lucide-react'
import type { ClaimLinkState, CreateClaimResult } from '@/hooks/useClaimLink'

const spectral = 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)'
const springs = { sheet: { type: 'spring' as const, stiffness: 340, damping: 32, mass: 0.9 } }

const glass = {
  inner: {
    background: 'rgba(255,255,255,0.46)',
    border: '1px solid rgba(255,255,255,0.56)',
  } as React.CSSProperties,
}

const QUICK_AMOUNTS = ['1', '2', '5', '10']

interface Props {
  open: boolean
  onClose: () => void
  claimState: ClaimLinkState
  displayName: string | null
}

export function ShareSheet({ open, onClose, claimState, displayName }: Props) {
  const [amount, setAmount] = useState('')
  const [result, setResult] = useState<CreateClaimResult | null>(null)
  const [copied, setCopied] = useState(false)

  // BUG FIX: disable during any in-flight stage, not only when idle
  const txIdle = claimState.txState.stage === 'idle' || claimState.txState.stage === 'error'
  const canCreate = parseFloat(amount) > 0 && txIdle && !result

  const handleClose = () => {
    claimState.reset()
    setResult(null)
    setAmount('')
    onClose()
  }

  const handleCreate = async () => {
    if (!canCreate) return
    const r = await claimState.createLink(amount, displayName ?? 'Someone')
    setResult(r)
  }

  const copyLink = () => {
    if (!result) return
    void navigator.clipboard.writeText(result.url).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const shareMessenger = () => {
    if (!result) return
    const fbUrl = `fb-messenger://share/?link=${encodeURIComponent(result.url)}`
    window.open(fbUrl, '_blank')
  }

  const shareNative = () => {
    if (!result) return
    if (navigator.share) {
      void navigator.share({
        title: `${displayName ?? 'Someone'} sent you $${result.link.amountUsdc} USDC`,
        text: 'Tap to claim your USDC — no gas needed.',
        url: result.url,
      })
    } else {
      copyLink()
    }
  }

  const isCreating = claimState.txState.stage === 'signing' || claimState.txState.stage === 'confirming'

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" />
          <motion.section
            className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
            style={{ background: 'rgba(255,255,255,0.90)', backdropFilter: 'blur(40px) saturate(200%)', WebkitBackdropFilter: 'blur(40px) saturate(200%)' }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={springs.sheet}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-1" style={{ background: spectral }} />
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1 w-10 rounded-full bg-black/10" />
            </div>

            <div className="px-5 pb-8 pt-2">
              <div className="mb-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Share2 className="size-4" style={{ color: 'var(--accent)' }} />
                  <h2 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>Send via Messenger</h2>
                </div>
                <button onClick={handleClose} className="rounded-full p-1.5 transition hover:opacity-60">
                  <X className="size-4" style={{ color: 'var(--muted)' }} />
                </button>
              </div>

              {!result ? (
                <div className="space-y-4">
                  {/* Amount entry */}
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Amount to send</label>
                    <div className="rounded-2xl p-4" style={glass.inner}>
                      <input
                        inputMode="decimal"
                        value={amount}
                        onChange={(e) => {
                          const v = e.target.value.replace(/[^0-9.]/g, '')
                          if (v === '' || /^\d*\.?\d{0,6}$/.test(v)) setAmount(v)
                        }}
                        placeholder="0.00"
                        className="display w-full bg-transparent text-3xl font-bold tabular-nums outline-none placeholder:text-slate-300"
                        style={{ color: 'var(--ink)' }}
                      />
                      <p className="mt-1 text-xs" style={{ color: 'var(--subtle)' }}>USDC · locked in escrow</p>
                    </div>
                    <div className="mt-2 flex gap-2">
                      {QUICK_AMOUNTS.map((q) => (
                        <button
                          key={q}
                          onClick={() => setAmount(q)}
                          className="flex-1 rounded-lg py-1.5 text-xs font-semibold transition hover:opacity-80"
                          style={{ background: amount === q ? 'var(--accent)' : 'rgba(18,45,69,0.07)', color: amount === q ? 'white' : 'var(--ink-2)' }}
                        >
                          ${q}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* OG preview mockup */}
                  {amount && parseFloat(amount) > 0 && (
                    <div className="overflow-hidden rounded-2xl" style={{ border: '1px solid rgba(18,45,69,0.12)' }}>
                      <p className="px-3 pt-2.5 text-xs font-semibold" style={{ color: 'var(--subtle)' }}>Messenger preview</p>
                      <div className="mx-3 mb-3 mt-1 overflow-hidden rounded-xl" style={{ background: 'var(--accent)' }}>
                        <div className="px-4 py-5">
                          <p className="display text-xl font-bold text-white/90">
                            {displayName ?? 'Someone'} sent you ${amount} USDC
                          </p>
                          <p className="mt-1 text-xs text-white/70">
                            Tap to claim your digital cash. No crypto experience needed.
                          </p>
                        </div>
                        <div
                          className="flex items-center justify-between px-4 py-2"
                          style={{ background: 'rgba(0,0,0,0.2)' }}
                        >
                          <span className="text-xs text-white/60">pay.example.com</span>
                          <ExternalLink className="size-3 text-white/60" />
                        </div>
                      </div>
                    </div>
                  )}

                  {claimState.txState.stage === 'error' && (
                    <div className="rounded-xl p-3" style={{ background: 'rgba(186,43,76,0.08)' }}>
                      <p className="text-xs" style={{ color: 'var(--danger)' }}>{claimState.txState.errorMessage}</p>
                    </div>
                  )}

                  <button
                    onClick={() => { void handleCreate() }}
                    disabled={!canCreate || isCreating}
                    className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                    style={{ background: 'var(--accent)' }}
                  >
                    {isCreating ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="size-4 animate-spin" />
                        Locking USDC in escrow...
                      </span>
                    ) : (
                      `Create $${amount || '0'} claim link`
                    )}
                  </button>
                </div>
              ) : (
                /* ── Share screen ─────────────────────────────────────────── */
                <div className="space-y-4">
                  {/* Success state */}
                  <div className="rounded-2xl p-4 text-center" style={{ ...glass.inner, border: '1px solid rgba(26,128,71,0.25)' }}>
                    <p className="text-xs font-semibold" style={{ color: 'var(--success)' }}>Link ready</p>
                    <p className="display mt-1 text-2xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                      ${result.link.amountUsdc} USDC
                    </p>
                    <p className="mt-1 text-xs" style={{ color: 'var(--muted)' }}>locked in escrow · expires in 72h</p>
                  </div>

                  {/* URL row */}
                  <div className="flex items-center gap-2 overflow-hidden rounded-xl p-3" style={glass.inner}>
                    <span className="mono flex-1 truncate text-xs" style={{ color: 'var(--ink-2)' }}>
                      {result.url}
                    </span>
                    <button onClick={copyLink} className="shrink-0 transition hover:opacity-70">
                      {copied ? <Check className="size-4" style={{ color: 'var(--success)' }} /> : <Copy className="size-4" style={{ color: 'var(--muted)' }} />}
                    </button>
                  </div>

                  {/* Share buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={shareMessenger}
                      className="flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold text-white transition hover:opacity-90"
                      style={{ background: '#0084ff' }}
                    >
                      <MessageCircle className="size-4" />
                      Messenger
                    </button>
                    <button
                      onClick={shareNative}
                      className="flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold transition hover:opacity-80"
                      style={glass.inner}
                    >
                      <Share2 className="size-4" style={{ color: 'var(--accent)' }} />
                      <span style={{ color: 'var(--ink)' }}>Share</span>
                    </button>
                  </div>

                  {claimState.txState.explorerUrl && (
                    <a
                      href={claimState.txState.explorerUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center justify-center gap-1 text-xs"
                      style={{ color: 'var(--accent-hover)' }}
                    >
                      View escrow transaction <ExternalLink className="size-3" />
                    </a>
                  )}
                </div>
              )}
            </div>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
