/**
 * SendSheet
 *
 * Bottom sheet for gasless USDC sends.
 * Enforces safe-mode and daily cap via useSafeSend.
 */

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Send } from 'lucide-react'
import { isAddress } from 'viem'
import { TxStatus } from './TxStatus'
import type { SafeSendState } from '@/hooks/useSafeSend'
import { BIOMETRIC_GATE_USDC } from '@/types/wallet'
import { parseUsdc } from '@/onchain-money'

const spectral = 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)'

const springs = {
  sheet: { type: 'spring' as const, stiffness: 340, damping: 32, mass: 0.9 },
}

interface Props {
  open: boolean
  onClose: () => void
  sender: SafeSendState
  balance: string | null
}

const QUICK_AMOUNTS = ['1', '5', '10', '25']

export function SendSheet({ open, onClose, sender, balance }: Props) {
  const [to, setTo] = useState('')
  const [amount, setAmount] = useState('')

  const isValidAddress = isAddress(to)
  const amountNum = parseFloat(amount)
  const isValidAmount = amountNum > 0 && !isNaN(amountNum)
  const needsBiometric = isValidAmount && parseUsdc(amount || '0') >= parseUsdc(String(BIOMETRIC_GATE_USDC))
  // BUG FIX: disable while any in-flight stage is active, not only 'idle'
  const txIdle = sender.txState.stage === 'idle' || sender.txState.stage === 'error'
  const canSend = isValidAddress && isValidAmount && txIdle

  const handleClose = () => {
    sender.reset()
    setTo('')
    setAmount('')
    onClose()
  }

  const handleSend = async () => {
    if (!canSend) return
    await sender.send({ to, amountUsdc: amount })
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" />
          <motion.section
            className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
            style={{ background: 'rgba(255,255,255,0.90)', backdropFilter: 'blur(40px) saturate(200%)', WebkitBackdropFilter: 'blur(40px) saturate(200%)' }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={springs.sheet}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Spectral strip */}
            <div className="h-1" style={{ background: spectral }} />

            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1 w-10 rounded-full bg-black/10" />
            </div>

            <div className="px-5 pb-8 pt-2">
              {/* Header */}
              <div className="mb-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Send className="size-4" style={{ color: 'var(--accent)' }} />
                  <h2 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>Send USDC</h2>
                </div>
                <button onClick={handleClose} className="rounded-full p-1.5 transition hover:opacity-60">
                  <X className="size-4" style={{ color: 'var(--muted)' }} />
                </button>
              </div>

              {sender.txState.stage === 'idle' || sender.txState.stage === 'biometric' ? (
                <div className="space-y-4">
                  {/* Recipient */}
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>
                      Recipient address
                    </label>
                    <input
                      type="text"
                      value={to}
                      onChange={(e) => setTo(e.target.value)}
                      placeholder="0x..."
                      className="mono w-full rounded-xl px-4 py-3 text-sm outline-none transition"
                      style={{
                        background: 'rgba(255,255,255,0.46)',
                        border: `1px solid ${isAddress(to) || to === '' ? 'rgba(255,255,255,0.56)' : 'rgba(186,43,76,0.4)'}`,
                        color: 'var(--ink)',
                      }}
                    />
                    {to !== '' && !isValidAddress && (
                      <p className="mt-1 text-xs" style={{ color: 'var(--danger)' }}>Invalid address format</p>
                    )}
                  </div>

                  {/* Amount */}
                  <div>
                    <div className="mb-1.5 flex items-center justify-between">
                      <label className="text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Amount (USDC)</label>
                      {balance && (
                        <button
                          onClick={() => setAmount(balance)}
                          className="text-xs font-medium"
                          style={{ color: 'var(--accent-hover)' }}
                        >
                          Max: {balance}
                        </button>
                      )}
                    </div>
                    <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.46)', border: '1px solid rgba(255,255,255,0.56)' }}>
                      <input
                        inputMode="decimal"
                        value={amount}
                        onChange={(e) => {
                          const v = e.target.value.replace(/[^0-9.]/g, '')
                          if (v === '' || /^\d*\.?\d{0,6}$/.test(v)) setAmount(v)
                        }}
                        placeholder="0.00"
                        className="display w-full bg-transparent text-3xl font-bold tabular-nums outline-none placeholder:text-slate-300"
                        style={{ color: 'var(--ink)' }}
                      />
                      <p className="mt-1 text-xs" style={{ color: 'var(--subtle)' }}>USDC · Arc Testnet</p>
                    </div>

                    {/* Quick amounts */}
                    <div className="mt-2 flex gap-2">
                      {QUICK_AMOUNTS.map((q) => (
                        <button
                          key={q}
                          onClick={() => setAmount(q)}
                          className="flex-1 rounded-lg py-1.5 text-xs font-semibold transition hover:opacity-80"
                          style={{ background: amount === q ? 'var(--accent)' : 'rgba(18,45,69,0.07)', color: amount === q ? 'white' : 'var(--ink-2)' }}
                        >
                          ${q}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Biometric warning */}
                  {needsBiometric && (
                    <div className="flex items-center gap-2 rounded-xl p-3" style={{ background: 'rgba(18,45,69,0.06)' }}>
                      <span className="text-xs" style={{ color: 'var(--muted)' }}>
                        Transfers above ${BIOMETRIC_GATE_USDC} require biometric re-authentication.
                      </span>
                    </div>
                  )}

                  {/* Safe-mode note */}
                  <div className="flex items-center gap-1.5 rounded-xl p-2.5" style={{ background: 'rgba(26,128,71,0.06)' }}>
                    <span className="text-xs" style={{ color: 'var(--success)' }}>
                      Safe Mode active · Zero gas fee · Only USDC transfers allowed
                    </span>
                  </div>

                  <TxStatus state={sender.txState} onReset={sender.reset} />

                  <button
                    onClick={() => { void handleSend() }}
                    disabled={!canSend}
                    className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                    style={{ background: 'var(--accent)' }}
                  >
                    Send {amount ? `$${amount} ` : ''}USDC
                  </button>
                </div>
              ) : (
                <TxStatus state={sender.txState} onReset={() => { sender.reset(); handleClose() }} />
              )}
            </div>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
