/**
 * UtilityPanel
 *
 * Local utility spending: airtime, data bundles, electricity, water.
 * Production: connect to Reloadly API or equivalent local aggregator.
 * Scaffold: shows product catalog UI with USDC spend flow stub.
 */

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Zap, Wifi, Lightbulb, Droplets, ChevronRight, Loader2, CheckCircle2 } from 'lucide-react'
import type { UtilityCategory, UtilityProduct } from '@/types/utility'

const spectral = 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)'
const springs = { sheet: { type: 'spring' as const, stiffness: 340, damping: 32, mass: 0.9 } }

const glass = {
  card: {
    background: 'rgba(255,255,255,0.64)',
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid rgba(255,255,255,0.68)',
    boxShadow: '0 8px 32px rgba(18,45,69,0.08)',
  } as React.CSSProperties,
  inner: {
    background: 'rgba(255,255,255,0.46)',
    border: '1px solid rgba(255,255,255,0.56)',
  } as React.CSSProperties,
}

// Demo product catalog — replace with Reloadly API data
const DEMO_PRODUCTS: UtilityProduct[] = [
  { id: 'airtime-100', name: 'Mobile Airtime $1', category: 'airtime', description: '$1 talk time credit', minUsdcAmount: 1, maxUsdcAmount: 1, country: 'US' },
  { id: 'airtime-500', name: 'Mobile Airtime $5', category: 'airtime', description: '$5 talk time credit', minUsdcAmount: 5, maxUsdcAmount: 5, country: 'US' },
  { id: 'data-1gb', name: 'Data Bundle 1GB', category: 'data', description: '1GB mobile data, 30 days', minUsdcAmount: 2, maxUsdcAmount: 2, country: 'US' },
  { id: 'data-5gb', name: 'Data Bundle 5GB', category: 'data', description: '5GB mobile data, 30 days', minUsdcAmount: 8, maxUsdcAmount: 8, country: 'US' },
  { id: 'elec-10', name: 'Electricity $10', category: 'electricity', description: 'Prepaid electricity token', minUsdcAmount: 10, maxUsdcAmount: 10, country: 'US' },
  { id: 'water-5', name: 'Water Bill $5', category: 'water', description: 'Utility water payment', minUsdcAmount: 5, maxUsdcAmount: 5, country: 'US' },
]

const CATEGORY_ICONS: Record<UtilityCategory, React.ReactNode> = {
  airtime: <Zap className="size-4" />,
  data: <Wifi className="size-4" />,
  electricity: <Lightbulb className="size-4" />,
  water: <Droplets className="size-4" />,
}

const CATEGORY_LABELS: Record<UtilityCategory, string> = {
  airtime: 'Airtime',
  data: 'Data',
  electricity: 'Electricity',
  water: 'Water',
}

interface Props {
  open: boolean
  onClose: () => void
  balance: string | null
}

type PurchaseState = 'idle' | 'confirming' | 'processing' | 'success' | 'error'

export function UtilityPanel({ open, onClose, balance }: Props) {
  const [selectedCategory, setSelectedCategory] = useState<UtilityCategory | 'all'>('all')
  const [selectedProduct, setSelectedProduct] = useState<UtilityProduct | null>(null)
  const [purchaseState, setPurchaseState] = useState<PurchaseState>('idle')
  const [errorMsg, setErrorMsg] = useState('')

  const categories: UtilityCategory[] = ['airtime', 'data', 'electricity', 'water']
  const filtered = selectedCategory === 'all'
    ? DEMO_PRODUCTS
    : DEMO_PRODUCTS.filter((p) => p.category === selectedCategory)

  const handleClose = () => {
    setPurchaseState('idle')
    setSelectedProduct(null)
    onClose()
  }

  const handlePurchase = async () => {
    if (!selectedProduct) return
    const bal = parseFloat(balance ?? '0')
    if (bal < selectedProduct.minUsdcAmount) {
      setErrorMsg(`Insufficient balance. You need $${selectedProduct.minUsdcAmount} USDC.`)
      setPurchaseState('error')
      return
    }
    setPurchaseState('processing')
    // In production: call /api/utility/airtime or Reloadly SDK here
    await new Promise((r) => setTimeout(r, 1800))
    setPurchaseState('success')
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" />
          <motion.section
            className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
            style={{ background: 'rgba(255,255,255,0.90)', backdropFilter: 'blur(40px) saturate(200%)', WebkitBackdropFilter: 'blur(40px) saturate(200%)', maxHeight: '85dvh', overflowY: 'auto' }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={springs.sheet}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-1" style={{ background: spectral }} />
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1 w-10 rounded-full bg-black/10" />
            </div>

            <div className="px-5 pb-8 pt-2">
              <div className="mb-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="size-4" style={{ color: 'var(--accent)' }} />
                  <h2 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>Pay Bills</h2>
                </div>
                <button onClick={handleClose} className="rounded-full p-1.5 transition hover:opacity-60">
                  <X className="size-4" style={{ color: 'var(--muted)' }} />
                </button>
              </div>

              {purchaseState === 'success' ? (
                <div className="flex flex-col items-center gap-4 py-8 text-center">
                  <CheckCircle2 className="size-12" style={{ color: 'var(--success)' }} />
                  <div>
                    <p className="display text-lg font-bold" style={{ color: 'var(--ink)' }}>Payment sent</p>
                    <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>
                      {selectedProduct?.name} — ${selectedProduct?.minUsdcAmount} USDC
                    </p>
                    <p className="mt-0.5 text-xs" style={{ color: 'var(--subtle)' }}>
                      Production: reference ID from Reloadly shown here
                    </p>
                  </div>
                  <button
                    onClick={() => { setPurchaseState('idle'); setSelectedProduct(null) }}
                    className="rounded-2xl px-6 py-2.5 text-sm font-semibold text-white"
                    style={{ background: 'var(--accent)' }}
                  >
                    Pay another bill
                  </button>
                </div>
              ) : selectedProduct ? (
                <div className="space-y-4">
                  <button
                    onClick={() => { setSelectedProduct(null); setPurchaseState('idle') }}
                    className="text-sm"
                    style={{ color: 'var(--muted)' }}
                  >
                    ← Back
                  </button>
                  <div className="rounded-2xl p-4" style={glass.inner}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{selectedProduct.name}</p>
                        <p className="text-xs" style={{ color: 'var(--muted)' }}>{selectedProduct.description}</p>
                      </div>
                      <span className="display text-xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                        ${selectedProduct.minUsdcAmount}
                      </span>
                    </div>
                  </div>

                  {purchaseState === 'error' && (
                    <div className="rounded-xl p-3" style={{ background: 'rgba(186,43,76,0.08)' }}>
                      <p className="text-xs" style={{ color: 'var(--danger)' }}>{errorMsg}</p>
                    </div>
                  )}

                  <div className="rounded-xl p-3" style={{ background: 'rgba(18,45,69,0.04)' }}>
                    <p className="text-xs" style={{ color: 'var(--subtle)' }}>
                      Production: deducts from your wallet via gasless user-op, routes to Reloadly or local aggregator.
                    </p>
                  </div>

                  <button
                    onClick={() => { void handlePurchase() }}
                    disabled={purchaseState === 'processing'}
                    className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-40"
                    style={{ background: 'var(--accent)' }}
                  >
                    {purchaseState === 'processing' ? (
                      <span className="flex items-center justify-center gap-2">
                        <Loader2 className="size-4 animate-spin" /> Processing...
                      </span>
                    ) : (
                      `Pay $${selectedProduct.minUsdcAmount} USDC`
                    )}
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Category filter */}
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {(['all', ...categories] as const).map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className="shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition"
                        style={{
                          background: selectedCategory === cat ? 'var(--accent)' : 'rgba(18,45,69,0.07)',
                          color: selectedCategory === cat ? 'white' : 'var(--ink-2)',
                        }}
                      >
                        {cat === 'all' ? 'All' : CATEGORY_LABELS[cat]}
                      </button>
                    ))}
                  </div>

                  {/* Product list */}
                  <div className="space-y-2">
                    {filtered.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => setSelectedProduct(p)}
                        className="flex w-full items-center justify-between rounded-2xl p-3.5 text-left transition hover:scale-[1.01]"
                        style={glass.inner}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="flex size-9 items-center justify-center rounded-xl"
                            style={{ background: 'rgba(18,45,69,0.07)' }}
                          >
                            <span style={{ color: 'var(--accent)' }}>{CATEGORY_ICONS[p.category]}</span>
                          </div>
                          <div>
                            <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>{p.name}</p>
                            <p className="text-xs" style={{ color: 'var(--muted)' }}>{p.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="display text-sm font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                            ${p.minUsdcAmount}
                          </span>
                          <ChevronRight className="size-4" style={{ color: 'var(--subtle)' }} />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
