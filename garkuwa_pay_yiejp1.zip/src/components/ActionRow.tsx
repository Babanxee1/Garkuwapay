/**
 * ActionRow
 *
 * Four primary actions in a 2×2 grid below the hero balance.
 * Each triggers a bottom sheet.
 */

import { Send, Download, Share2, Zap } from 'lucide-react'

const glass = {
  pill: {
    background: 'rgba(255,255,255,0.58)',
    backdropFilter: 'blur(12px)',
    WebkitBackdropFilter: 'blur(12px)',
    border: '1px solid rgba(255,255,255,0.66)',
  } as React.CSSProperties,
}

interface ActionButtonProps {
  icon: React.ReactNode
  label: string
  onClick: () => void
  highlight?: boolean
}

function ActionButton({ icon, label, onClick, highlight }: ActionButtonProps) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-2 rounded-2xl py-4 transition-all hover:scale-[1.03] active:scale-[0.97]"
      style={highlight ? { background: 'var(--accent)', boxShadow: '0 4px 16px rgba(18,45,69,0.25)' } : glass.pill}
    >
      <div
        className={`flex size-9 items-center justify-center rounded-xl ${highlight ? 'bg-white/20' : ''}`}
        style={highlight ? {} : { background: 'rgba(18,45,69,0.07)' }}
      >
        <span style={{ color: highlight ? 'white' : 'var(--accent)' }}>{icon}</span>
      </div>
      <span
        className="text-xs font-semibold"
        style={{ color: highlight ? 'rgba(255,255,255,0.95)' : 'var(--ink-2)' }}
      >
        {label}
      </span>
    </button>
  )
}

interface Props {
  onSend: () => void
  onClaim: () => void
  onShare: () => void
  onUtility: () => void
  hasPendingClaim: boolean
}

export function ActionRow({ onSend, onClaim, onShare, onUtility, hasPendingClaim }: Props) {
  return (
    <div className="grid grid-cols-4 gap-2">
      <ActionButton icon={<Send className="size-4" />} label="Send" onClick={onSend} highlight />
      <ActionButton
        icon={
          <div className="relative">
            <Download className="size-4" />
            {hasPendingClaim && (
              <span
                className="absolute -right-1 -top-1 flex size-2 rounded-full"
                style={{ background: 'var(--danger)' }}
              />
            )}
          </div>
        }
        label="Claim"
        onClick={onClaim}
      />
      <ActionButton icon={<Share2 className="size-4" />} label="Share" onClick={onShare} />
      <ActionButton icon={<Zap className="size-4" />} label="Pay bills" onClick={onUtility} />
    </div>
  )
}
