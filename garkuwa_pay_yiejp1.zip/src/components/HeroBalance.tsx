/**
 * HeroBalance
 *
 * Dominant object on the wallet screen: live USDC balance + account address.
 * Daily spend progress bar anchored to the $50 cap.
 */

import { useState } from 'react'
import { Copy, Check, TrendingUp } from 'lucide-react'
import { motion } from 'framer-motion'
import type { UsdcBalanceState } from '@/hooks/useUsdcBalance'
import { getDailySpendPercent, getDailySpentUsdc } from '@/utils/dailyCap'
import { DAILY_CAP_USDC } from '@/types/wallet'

const glass = {
  card: {
    background: 'rgba(255,255,255,0.64)',
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid rgba(255,255,255,0.68)',
    boxShadow: '0 8px 32px rgba(18,45,69,0.08), inset 0 1px 0 rgba(255,255,255,0.55)',
  } as React.CSSProperties,
}

interface Props {
  balance: UsdcBalanceState
  address: string
  displayName: string | null
}

function shortAddress(addr: string): string {
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`
}

export function HeroBalance({ balance, address, displayName }: Props) {
  const [copied, setCopied] = useState(false)
  // BUG FIX: address may be an empty string during the brief window between
  // session restore starting and the MSCA address resolving — guard both calls.
  const spendPercent = address ? getDailySpendPercent(address) : 0
  const spentUsdc = address ? getDailySpentUsdc(address) : '0.00'

  const copyAddress = () => {
    void navigator.clipboard.writeText(address).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <section className="rounded-3xl p-5" style={glass.card}>
      {/* Header row */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <div
            className="flex size-5 items-center justify-center rounded-md"
            style={{ background: 'rgba(26,128,71,0.12)' }}
          >
            <TrendingUp className="size-3" style={{ color: 'var(--success)' }} />
          </div>
          <span className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>
            Available Balance
          </span>
        </div>

        {/* Address chip */}
        <button
          onClick={copyAddress}
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition hover:opacity-80"
          style={{ background: 'rgba(18,45,69,0.06)', color: 'var(--ink-2)' }}
        >
          <span className="mono">{shortAddress(address)}</span>
          {copied ? <Check className="size-3" style={{ color: 'var(--success)' }} /> : <Copy className="size-3" />}
        </button>
      </div>

      {/* Hero amount */}
      <div className="flex items-baseline gap-2">
        {balance.loading && balance.raw === null ? (
          <div className="h-11 w-32 animate-pulse rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }} />
        ) : (
          <motion.span
            key={balance.formatted ?? 'loading'}
            initial={{ opacity: 0.6, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="display text-5xl font-bold tabular-nums"
            style={{ color: 'var(--ink)', letterSpacing: '-0.04em' }}
          >
            {balance.formatted ?? '0.00'}
          </motion.span>
        )}
        <span className="text-xl font-medium" style={{ color: 'var(--subtle)' }}>USDC</span>
      </div>

      {/* Name + network */}
      <p className="mt-1 text-xs" style={{ color: 'var(--muted)' }}>
        {displayName ? `${displayName} · ` : ''}Arc Testnet · Zero gas fees
      </p>

      {/* Daily spend progress */}
      <div className="mt-4">
        <div className="mb-1.5 flex items-center justify-between">
          <span className="text-xs" style={{ color: 'var(--subtle)' }}>Daily limit</span>
          <span className="mono text-xs tabular-nums" style={{ color: 'var(--muted)' }}>
            ${spentUsdc} / ${DAILY_CAP_USDC}
          </span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: 'rgba(18,45,69,0.08)' }}>
          <motion.div
            className="h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${spendPercent}%` }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            style={{
              background: spendPercent > 80
                ? 'var(--danger)'
                : spendPercent > 50
                ? '#f59e0b'
                : 'var(--success)',
            }}
          />
        </div>
      </div>
    </section>
  )
}
