/**
 * AuthGate — sign in with passkey or external wallet
 */

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Fingerprint, LogIn, AlertCircle, Loader2, ShieldCheck, Wallet, RotateCcw, Copy, Check, Trash2 } from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import type { PasskeyWalletState } from '@/hooks/usePasskeyWallet'

const glass = {
  card: {
    background: 'rgba(255,255,255,0.64)',
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    border: '1px solid rgba(255,255,255,0.68)',
    boxShadow: '0 8px 32px rgba(18,45,69,0.08), inset 0 1px 0 rgba(255,255,255,0.55)',
  } as React.CSSProperties,
  inner: {
    background: 'rgba(255,255,255,0.46)',
    border: '1px solid rgba(255,255,255,0.56)',
  } as React.CSSProperties,
}

interface Props {
  wallet: PasskeyWalletState
  onExternalWalletConnected: () => void
  isExternalConnected: boolean
}

type Step = 'welcome' | 'register' | 'login' | 'recover'

export function AuthGate({ wallet, onExternalWalletConnected, isExternalConnected }: Props) {
  const [step, setStep] = useState<Step>('welcome')
  const [name, setName] = useState('')
  const [copied, setCopied] = useState(false)
  const [resetDone, setResetDone] = useState(false)

  const isLoading =
    wallet.authState.status === 'registering' || wallet.authState.status === 'logging_in'
  const error =
    wallet.authState.status === 'error' ? wallet.authState.message : null

  // When external wallet connects, notify parent immediately
  useEffect(() => {
    if (isExternalConnected) onExternalWalletConnected()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isExternalConnected])

  const handleRegister = async () => {
    if (!name.trim()) return
    await wallet.register(name.trim())
  }

  const handleLogin  = async () => { await wallet.login() }
  const handleRecover = async () => { await wallet.recover() }

  const handleReset = () => {
    // Clear stored passkey credential from both storage layers
    localStorage.removeItem('garkuwa:credential')
    sessionStorage.removeItem('garkuwa:credential')
    wallet.logout()
    setResetDone(true)
    setTimeout(() => setResetDone(false), 2500)
  }

  const copyAddress = (addr: string) => {
    void navigator.clipboard.writeText(addr).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div
      className="relative min-h-dvh overflow-hidden flex items-center justify-center"
      style={{ background: 'linear-gradient(180deg, #f9f9fc 0%, #fffcf7 52%, #fbf7f2 100%)' }}
    >
      {/* Background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div style={{ position: 'absolute', top: '10%', left: '5%', width: 300, height: 300, borderRadius: '50%', background: 'radial-gradient(circle, rgba(133,177,237,0.22) 0%, transparent 70%)', filter: 'blur(60px)' }} />
        <div style={{ position: 'absolute', bottom: '10%', right: '5%', width: 280, height: 280, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,205,131,0.20) 0%, transparent 70%)', filter: 'blur(58px)' }} />
      </div>

      <div className="relative z-10 w-full max-w-md px-4 py-8">
        <AnimatePresence mode="wait">

          {/* ── Welcome ── */}
          {step === 'welcome' && (
            <motion.div key="welcome" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}>
              {/* Logo */}
              <div className="mb-8 flex flex-col items-center gap-3">
                <div className="flex size-16 items-center justify-center rounded-2xl" style={{ background: 'var(--accent)', boxShadow: '0 8px 24px rgba(18,45,69,0.25)' }}>
                  <span className="display text-2xl font-bold text-white">$</span>
                </div>
                <h1 className="display text-3xl font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}>Garkuwa Pay</h1>
                <p className="text-sm text-center max-w-xs" style={{ color: 'var(--muted)' }}>
                  Send and claim USDC with a single tap. No gas fees, no seed phrases.
                </p>
              </div>

              {/* CTAs */}
              <div className="rounded-3xl p-5 space-y-3" style={glass.card}>

                {/* ── PRIMARY: External wallet ── */}
                <ConnectKitButton.Custom>
                  {({ isConnecting, show }) => (
                    <button
                      onClick={show}
                      disabled={isConnecting}
                      className="w-full rounded-2xl py-4 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50"
                      style={{ background: 'var(--accent)' }}
                    >
                      <span className="flex items-center justify-center gap-2">
                        {isConnecting
                          ? <><Loader2 className="size-4 animate-spin" />Connecting…</>
                          : <><Wallet className="size-4" />Connect external wallet</>}
                      </span>
                    </button>
                  )}
                </ConnectKitButton.Custom>
                <p className="text-center text-xs" style={{ color: 'var(--subtle)' }}>
                  MetaMask · Coinbase Wallet · WalletConnect · and more
                </p>

                {/* Divider */}
                <div className="flex items-center gap-3 py-1">
                  <div className="flex-1 h-px" style={{ background: 'rgba(18,45,69,0.10)' }} />
                  <span className="text-xs" style={{ color: 'var(--muted)' }}>or use a passkey</span>
                  <div className="flex-1 h-px" style={{ background: 'rgba(18,45,69,0.10)' }} />
                </div>

                {/* Passkey options */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setStep('register')}
                    className="rounded-2xl py-3 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99]"
                    style={glass.inner}
                  >
                    <span className="flex items-center justify-center gap-1.5" style={{ color: 'var(--ink)' }}>
                      <Fingerprint className="size-4" />
                      New wallet
                    </span>
                  </button>
                  <button
                    onClick={() => setStep(wallet.hasStoredCredential ? 'login' : 'recover')}
                    className="rounded-2xl py-3 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99]"
                    style={glass.inner}
                  >
                    <span className="flex items-center justify-center gap-1.5" style={{ color: 'var(--ink)' }}>
                      <LogIn className="size-4" />
                      Sign in
                    </span>
                  </button>
                </div>

                {/* Reset link */}
                <div className="pt-1 flex justify-center">
                  <button
                    onClick={handleReset}
                    className="flex items-center gap-1.5 text-xs py-1 px-2 rounded-lg transition hover:opacity-70"
                    style={{ color: resetDone ? 'var(--success)' : 'var(--subtle)' }}
                  >
                    {resetDone
                      ? <><Check className="size-3" />Session cleared</>
                      : <><Trash2 className="size-3" />Clear stored session</>}
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ── Register ── */}
          {step === 'register' && (
            <motion.div key="register" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}>
              <button onClick={() => setStep('welcome')} className="mb-6 text-sm" style={{ color: 'var(--muted)' }}>← Back</button>
              <div className="rounded-3xl p-6 space-y-5" style={glass.card}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex size-10 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
                    <Fingerprint className="size-5" style={{ color: 'var(--accent)' }} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Create your wallet</p>
                    <p className="text-xs" style={{ color: 'var(--muted)' }}>Secured by Touch ID or Face ID</p>
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>Your display name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') void handleRegister() }}
                    placeholder="e.g. Alice M."
                    className="w-full rounded-xl px-4 py-3 text-sm outline-none transition"
                    style={{ ...glass.inner, color: 'var(--ink)' }}
                  />
                </div>

                {error && (
                  <div className="flex items-start gap-2 rounded-xl p-3" style={{ background: 'rgba(186,43,76,0.08)' }}>
                    <AlertCircle className="mt-0.5 size-4 shrink-0" style={{ color: 'var(--danger)' }} />
                    <p className="text-xs" style={{ color: 'var(--danger)' }}>{error}</p>
                  </div>
                )}

                <button
                  onClick={() => { void handleRegister() }}
                  disabled={!name.trim() || isLoading}
                  className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                  style={{ background: 'var(--accent)' }}
                >
                  {isLoading
                    ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" />Setting up passkey…</span>
                    : 'Register with Touch ID / Face ID'}
                </button>

                <div className="flex items-start gap-2">
                  <ShieldCheck className="mt-0.5 size-4 shrink-0" style={{ color: 'var(--success)' }} />
                  <p className="text-xs" style={{ color: 'var(--muted)' }}>Non-custodial. No seed phrase. Key stays on your device.</p>
                </div>
              </div>
            </motion.div>
          )}

          {/* ── Login ── */}
          {step === 'login' && (
            <motion.div key="login" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}>
              <button onClick={() => setStep('welcome')} className="mb-6 text-sm" style={{ color: 'var(--muted)' }}>← Back</button>
              <div className="rounded-3xl p-6 space-y-5" style={glass.card}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex size-10 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
                    <LogIn className="size-5" style={{ color: 'var(--accent)' }} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Welcome back</p>
                    <p className="text-xs" style={{ color: 'var(--muted)' }}>Use your saved passkey to sign in</p>
                  </div>
                </div>

                {wallet.accountAddress && (
                  <div className="rounded-xl px-3 py-2.5 flex items-center justify-between" style={{ background: 'rgba(18,45,69,0.04)' }}>
                    <span className="text-xs font-mono" style={{ color: 'var(--ink-2)' }}>
                      {wallet.accountAddress.slice(0, 10)}…{wallet.accountAddress.slice(-8)}
                    </span>
                    <button onClick={() => copyAddress(wallet.accountAddress!)} className="ml-2 p-1 rounded-lg transition hover:opacity-70">
                      {copied ? <Check className="size-3.5" style={{ color: 'var(--success)' }} /> : <Copy className="size-3.5" style={{ color: 'var(--muted)' }} />}
                    </button>
                  </div>
                )}

                {error && (
                  <div className="flex items-start gap-2 rounded-xl p-3" style={{ background: 'rgba(186,43,76,0.08)' }}>
                    <AlertCircle className="mt-0.5 size-4 shrink-0" style={{ color: 'var(--danger)' }} />
                    <p className="text-xs" style={{ color: 'var(--danger)' }}>{error}</p>
                  </div>
                )}

                <button
                  onClick={() => { void handleLogin() }}
                  disabled={isLoading}
                  className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                  style={{ background: 'var(--accent)' }}
                >
                  {isLoading
                    ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" />Authenticating…</span>
                    : 'Sign in with Touch ID / Face ID'}
                </button>

                <button onClick={() => setStep('recover')} className="w-full text-center text-xs py-1" style={{ color: 'var(--muted)' }}>
                  Lost access? Recover wallet →
                </button>
              </div>
            </motion.div>
          )}

          {/* ── Recover ── */}
          {step === 'recover' && (
            <motion.div key="recover" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}>
              <button onClick={() => setStep('welcome')} className="mb-6 text-sm" style={{ color: 'var(--muted)' }}>← Back</button>
              <div className="rounded-3xl p-6 space-y-5" style={glass.card}>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex size-10 items-center justify-center rounded-xl" style={{ background: 'rgba(18,45,69,0.08)' }}>
                    <RotateCcw className="size-5" style={{ color: 'var(--accent)' }} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>Recover wallet</p>
                    <p className="text-xs" style={{ color: 'var(--muted)' }}>Use your saved passkey on this device</p>
                  </div>
                </div>

                <div className="rounded-2xl p-3 space-y-1" style={{ background: 'rgba(18,45,69,0.04)', border: '1px solid rgba(18,45,69,0.06)' }}>
                  <p className="text-xs font-medium" style={{ color: 'var(--ink)' }}>How recovery works</p>
                  <p className="text-xs" style={{ color: 'var(--muted)' }}>
                    Your browser will show all passkeys saved for Garkuwa Pay on this device. Select the correct one and authenticate — your wallet address is restored instantly.
                  </p>
                </div>

                {error && (
                  <div className="flex items-start gap-2 rounded-xl p-3" style={{ background: 'rgba(186,43,76,0.08)' }}>
                    <AlertCircle className="mt-0.5 size-4 shrink-0" style={{ color: 'var(--danger)' }} />
                    <p className="text-xs" style={{ color: 'var(--danger)' }}>{error}</p>
                  </div>
                )}

                <button
                  onClick={() => { void handleRecover() }}
                  disabled={isLoading}
                  className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                  style={{ background: 'var(--accent)' }}
                >
                  {isLoading
                    ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" />Recovering…</span>
                    : 'Recover with saved passkey'}
                </button>

                <div className="pt-2 border-t" style={{ borderColor: 'rgba(18,45,69,0.08)' }}>
                  <p className="text-xs text-center" style={{ color: 'var(--muted)' }}>
                    Passkey not found?{' '}
                    <button onClick={() => setStep('welcome')} className="underline" style={{ color: 'var(--accent)' }}>
                      Connect an external wallet
                    </button>{' '}
                    instead.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  )
}
