/**
 * ClaimSheet
 *
 * Bottom sheet for claiming USDC from an escrow link.
 * Auto-populates if ?claim= is in the URL.
 */

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Download, Gift, Clock } from 'lucide-react'
import { TxStatus } from './TxStatus'
import type { ClaimLinkState } from '@/hooks/useClaimLink'

const spectral = 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)'
const springs = { sheet: { type: 'spring' as const, stiffness: 340, damping: 32, mass: 0.9 } }

const glass = {
  inner: {
    background: 'rgba(255,255,255,0.46)',
    border: '1px solid rgba(255,255,255,0.56)',
  } as React.CSSProperties,
}

interface Props {
  open: boolean
  onClose: () => void
  claimState: ClaimLinkState
}

export function ClaimSheet({ open, onClose, claimState }: Props) {
  // BUG FIX: pendingClaim can arrive after mount (async session restore populates it).
  // Mirror it into local state so the input stays pre-filled when the sheet opens.
  const [claimId, setClaimId] = useState(claimState.pendingClaim?.claimId ?? '')
  // Capture time once via lazy initializer — avoids calling Date.now() in render body
  const [mountTime] = useState<number>(() => Date.now())
  const resolvedLink = claimId ? claimState.resolveLink(claimId) : null

  const handleClose = () => {
    claimState.reset()
    setClaimId('')
    onClose()
  }

  const handleClaim = async () => {
    if (!claimId) return
    await claimState.claimLink(claimId)
  }

  const isExpired = resolvedLink != null && mountTime > resolvedLink.expiresAt
  const isClaimed = resolvedLink?.status === 'claimed'
  const canClaim = !!claimId && !isExpired && !isClaimed && claimState.txState.stage === 'idle'

  const timeLeft = resolvedLink != null
    ? Math.max(0, Math.floor((resolvedLink.expiresAt - mountTime) / 1000 / 3600))
    : null

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" />
          <motion.section
            className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
            style={{ background: 'rgba(255,255,255,0.90)', backdropFilter: 'blur(40px) saturate(200%)', WebkitBackdropFilter: 'blur(40px) saturate(200%)' }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={springs.sheet}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-1" style={{ background: spectral }} />
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1 w-10 rounded-full bg-black/10" />
            </div>

            <div className="px-5 pb-8 pt-2">
              <div className="mb-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Download className="size-4" style={{ color: 'var(--accent)' }} />
                  <h2 className="display text-base font-bold" style={{ color: 'var(--ink)' }}>Claim USDC</h2>
                </div>
                <button onClick={handleClose} className="rounded-full p-1.5 transition hover:opacity-60">
                  <X className="size-4" style={{ color: 'var(--muted)' }} />
                </button>
              </div>

              {claimState.txState.stage === 'idle' && (
                <div className="space-y-4">
                  {/* Claim preview card */}
                  {resolvedLink && !isExpired && !isClaimed && (
                    <div className="rounded-2xl p-4 text-center" style={{ ...glass.inner, border: '1px solid rgba(26,128,71,0.25)' }}>
                      <Gift className="mx-auto mb-2 size-6" style={{ color: 'var(--success)' }} />
                      <p className="display text-2xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                        ${resolvedLink.amountUsdc} USDC
                      </p>
                      <p className="mt-1 text-sm font-medium" style={{ color: 'var(--ink-2)' }}>
                        from {resolvedLink.senderName}
                      </p>
                      {timeLeft !== null && (
                        <div className="mt-2 flex items-center justify-center gap-1">
                          <Clock className="size-3" style={{ color: 'var(--muted)' }} />
                          <span className="text-xs" style={{ color: 'var(--muted)' }}>
                            Expires in {timeLeft}h
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {isClaimed && (
                    <div className="rounded-2xl p-4 text-center" style={glass.inner}>
                      <p className="text-sm font-medium" style={{ color: 'var(--muted)' }}>
                        This link has already been claimed.
                      </p>
                    </div>
                  )}

                  {isExpired && !isClaimed && (
                    <div className="rounded-2xl p-4 text-center" style={{ ...glass.inner, border: '1px solid rgba(186,43,76,0.2)' }}>
                      <p className="text-sm font-medium" style={{ color: 'var(--danger)' }}>
                        This claim link has expired.
                      </p>
                    </div>
                  )}

                  {/* Manual claim ID input */}
                  {!claimState.pendingClaim && (
                    <div>
                      <label className="mb-1.5 block text-xs font-semibold" style={{ color: 'var(--ink-2)' }}>
                        Paste your claim link or ID
                      </label>
                      <input
                        type="text"
                        value={claimId}
                        onChange={(e) => {
                          const v = e.target.value
                          const match = v.match(/claim=([a-f0-9]{32})/)
                          setClaimId(match ? match[1] : v.replace(/[^a-f0-9]/g, '').slice(0, 32))
                        }}
                        placeholder="Paste claim link here..."
                        className="w-full rounded-xl px-4 py-3 text-sm outline-none"
                        style={{ ...glass.inner, color: 'var(--ink)' }}
                      />
                    </div>
                  )}

                  <button
                    onClick={() => { void handleClaim() }}
                    disabled={!canClaim}
                    className="w-full rounded-2xl py-3.5 text-sm font-semibold text-white transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                    style={{ background: 'var(--accent)' }}
                  >
                    Claim {resolvedLink ? `$${resolvedLink.amountUsdc} ` : ''}USDC
                  </button>
                </div>
              )}

              {claimState.txState.stage !== 'idle' && (
                <TxStatus state={claimState.txState} onReset={() => { claimState.reset(); handleClose() }} />
              )}
            </div>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
