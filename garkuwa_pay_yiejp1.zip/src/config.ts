/**
 * wagmi configuration
 * Built with Arc Studio — https://studio.arc.io
 */

import { http, createConfig } from 'wagmi'
import { mainnet } from 'wagmi/chains'
import { arcTestnet } from 'viem/chains'
import { injected, walletConnect, coinbaseWallet } from 'wagmi/connectors'
import { registerChain } from './tracing'

// Pre-register chain RPC URLs so trace events show correct chain names immediately
registerChain(arcTestnet.id, arcTestnet.rpcUrls.default.http[0])

// WalletConnect project ID — get a free one at https://cloud.walletconnect.com
// Without it, only injected (MetaMask/browser) wallets are available.
const wcProjectId = import.meta.env.VITE_WC_PROJECT_ID as string | undefined

export const config = createConfig({
  chains: [arcTestnet, mainnet],
  connectors: [
    injected(),                                    // MetaMask, Rabby, browser wallets
    coinbaseWallet({ appName: 'Garkuwa Pay' }),    // Coinbase Wallet
    ...(wcProjectId
      ? [walletConnect({ projectId: wcProjectId })]
      : []),                                       // WalletConnect (requires project ID)
  ],
  transports: {
    [arcTestnet.id]: http(),
    [mainnet.id]: http(),
  },
})
