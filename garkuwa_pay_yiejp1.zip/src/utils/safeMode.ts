/**
 * Safe-Mode Call Filter
 *
 * Enforces Safe-Mode wallet rules before any user operation is submitted:
 *  - Only USDC transfer() and approve() are permitted
 *  - eth_sign and open allowances are always blocked
 *  - Non-USDC contract interactions are blocked
 *
 * Call `assertSafeCall` before every sendUserOperation. It throws a
 * SafeModeError (caught by useSafeSend) if the call violates a rule.
 */

import { type Hex, encodeFunctionData, decodeFunctionData } from 'viem'
import { getUsdc } from '@/onchain-facts'
import type { SafeModeViolation } from '@/types/wallet'

// Minimal ERC-20 ABI fragments we care about
const ERC20_TRANSFER_ABI = [
  {
    name: 'transfer',
    type: 'function',
    inputs: [
      { name: 'to', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
] as const

const ERC20_APPROVE_ABI = [
  {
    name: 'approve',
    type: 'function',
    inputs: [
      { name: 'spender', type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
] as const

export class SafeModeError extends Error {
  constructor(public readonly violation: SafeModeViolation) {
    super(violation.description)
    this.name = 'SafeModeError'
  }
}

export interface SafeCall {
  to: string
  data: Hex
  value?: bigint
}

/**
 * Validates a single call for Safe-Mode compliance on Arc Testnet (chainId 5042002).
 * Extend `chainId` param for other chains.
 */
export function assertSafeCall(call: SafeCall, chainId = 5042002): void {
  const usdcFact = getUsdc(chainId)
  const usdcAddress = usdcFact?.address?.toLowerCase()

  // 1. Block value transfers to non-USDC contracts (native USDC is gas on Arc)
  //    On Arc, native value sends are USDC, so we allow those separately.

  // 2. Block calls to anything that is not the USDC contract
  if (usdcAddress && call.to.toLowerCase() !== usdcAddress) {
    throw new SafeModeError({
      block: 'non_usdc_contract',
      description:
        'Safe Mode only allows USDC transfers and approvals. Calls to other contracts are blocked.',
    })
  }

  // 3. Inspect the calldata — must be transfer() or approve()
  if (call.data && call.data !== '0x') {
    const selector = call.data.slice(0, 10).toLowerCase()
    const transferSelector = encodeFunctionData({
      abi: ERC20_TRANSFER_ABI,
      functionName: 'transfer',
      args: ['0x0000000000000000000000000000000000000000', 0n],
    }).slice(0, 10).toLowerCase()
    const approveSelector = encodeFunctionData({
      abi: ERC20_APPROVE_ABI,
      functionName: 'approve',
      args: ['0x0000000000000000000000000000000000000000', 0n],
    }).slice(0, 10).toLowerCase()

    if (selector !== transferSelector && selector !== approveSelector) {
      throw new SafeModeError({
        block: 'non_usdc_contract',
        description:
          'Safe Mode blocks this operation. Only USDC send and allow are permitted.',
      })
    }

    // 4. Block unlimited (max uint256) approvals
    if (selector === approveSelector) {
      try {
        const decoded = decodeFunctionData({
          abi: ERC20_APPROVE_ABI,
          data: call.data,
        })
        const MAX_UINT256 = BigInt('0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')
        if (decoded.args && decoded.args[1] === MAX_UINT256) {
          throw new SafeModeError({
            block: 'open_allowance',
            description:
              'Unlimited token approvals are blocked in Safe Mode. Use a specific amount instead.',
          })
        }
      } catch (err) {
        if (err instanceof SafeModeError) throw err
        // Decode failed → pass through (not an approve call)
      }
    }
  }
}

/**
 * Checks if a method name is an `eth_sign` variant that Safe Mode blocks.
 */
export function isBlockedSignMethod(method: string): boolean {
  const blocked = ['eth_sign', 'personal_sign', 'eth_signTypedData']
  return blocked.some((m) => method.toLowerCase().includes(m.toLowerCase()))
}
