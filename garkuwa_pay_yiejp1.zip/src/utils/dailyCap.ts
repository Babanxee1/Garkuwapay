/**
 * Daily Spending Cap Tracker
 *
 * Tracks cumulative USDC spend per UTC calendar day.
 * Stored in localStorage (keyed by wallet address + date).
 * Cap: $50 USDC/day. Biometric re-auth gate: >$20 USDC per tx.
 */

import { formatUsdc, parseUsdc } from '@/onchain-money'
import { DAILY_CAP_USDC, BIOMETRIC_GATE_USDC } from '@/types/wallet'
import type { DailySpend } from '@/types/wallet'

const STORAGE_KEY = (address: string) => `flowpay:daily:${address.toLowerCase()}`

function todayUtc(): string {
  return new Date().toISOString().slice(0, 10) // "YYYY-MM-DD"
}

function getSpend(address: string): DailySpend {
  try {
    const raw = localStorage.getItem(STORAGE_KEY(address))
    if (raw) {
      const parsed = JSON.parse(raw) as { dateUtc: string; spentRaw: string }
      if (parsed.dateUtc === todayUtc()) {
        return { dateUtc: parsed.dateUtc, spentRaw: BigInt(parsed.spentRaw) }
      }
    }
  } catch {
    // Ignore corrupt storage
  }
  return { dateUtc: todayUtc(), spentRaw: 0n }
}

function setSpend(address: string, spend: DailySpend): void {
  localStorage.setItem(
    STORAGE_KEY(address),
    JSON.stringify({ dateUtc: spend.dateUtc, spentRaw: spend.spentRaw.toString() }),
  )
}

/** Current cumulative spend for today in human-readable USDC string */
export function getDailySpentUsdc(address: string): string {
  const spend = getSpend(address)
  return formatUsdc(spend.spentRaw)
}

/** Returns the remaining daily budget in raw ERC-20 units */
export function getRemainingRaw(address: string): bigint {
  const cap = parseUsdc(String(DAILY_CAP_USDC))
  const spend = getSpend(address)
  const remaining = cap - spend.spentRaw
  return remaining > 0n ? remaining : 0n
}

/**
 * Validates a spend against the daily cap.
 * Returns { ok: true } if within cap, { ok: false, reason } otherwise.
 */
export function checkDailyCap(
  address: string,
  amountRaw: bigint,
): { ok: boolean; reason?: string } {
  const cap = parseUsdc(String(DAILY_CAP_USDC))
  const spend = getSpend(address)
  const newTotal = spend.spentRaw + amountRaw
  if (newTotal > cap) {
    const remaining = formatUsdc(cap - spend.spentRaw)
    return {
      ok: false,
      reason: `Daily limit of $${DAILY_CAP_USDC} USDC reached. You have $${remaining} USDC remaining today.`,
    }
  }
  return { ok: true }
}

/** Returns true if the amount requires biometric re-authentication */
export function requiresBiometric(amountRaw: bigint): boolean {
  const gate = parseUsdc(String(BIOMETRIC_GATE_USDC))
  return amountRaw >= gate
}

/** Records a completed spend against the daily cap */
export function recordSpend(address: string, amountRaw: bigint): void {
  const spend = getSpend(address)
  setSpend(address, {
    dateUtc: todayUtc(),
    spentRaw: spend.spentRaw + amountRaw,
  })
}

/** Returns today's spend percentage (0–100) for a progress bar */
export function getDailySpendPercent(address: string): number {
  const cap = parseUsdc(String(DAILY_CAP_USDC))
  const spend = getSpend(address)
  if (cap === 0n) return 0
  return Math.min(100, Math.round(Number((spend.spentRaw * 100n) / cap)))
}
