/**
 * Claim URL Utilities
 *
 * Helpers for building and parsing escrow claim links.
 * In production, the base URL would be a dedicated short domain.
 */

const APP_BASE = typeof window !== 'undefined' ? window.location.origin : 'https://pay.example.com'

/** Build a claim URL from a claimId */
export function buildClaimUrl(claimId: string): string {
  return `${APP_BASE}?claim=${claimId}`
}

/** Extract a claimId from the current URL */
export function extractClaimId(): string | null {
  if (typeof window === 'undefined') return null
  const params = new URLSearchParams(window.location.search)
  return params.get('claim')
}

/** Build the OG meta page URL (server-rendered with rich meta tags) */
export function buildOgUrl(claimId: string): string {
  return `${APP_BASE}/api/og/${claimId}`
}

/** Generate a client-side preview of the OG title */
export function buildOgTitle(senderName: string, amountUsdc: string): string {
  return `${senderName} sent you $${amountUsdc} USDC`
}

/** Generate the OG description */
export function buildOgDescription(): string {
  return 'Tap to claim your digital cash. No crypto experience needed — just tap and it\'s yours in seconds.'
}

/**
 * Generates a pseudo-random claimId for demo purposes.
 * In production, the escrow contract emits a bytes32 topic that becomes the claimId.
 */
export function generateClaimId(): string {
  const bytes = new Uint8Array(16)
  crypto.getRandomValues(bytes)
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}
