/* oxlint-disable typescript/no-unsafe-assignment, typescript/no-unsafe-call, typescript/no-unsafe-member-access, typescript/no-unsafe-argument, typescript/no-explicit-any */
/**
 * useClaimLink
 *
 * Manages USDC escrow claim links:
 *  - createLink: locks USDC in escrow, returns a shareable URL + OG data
 *  - claimLink: claims USDC from escrow into the user's MSCA
 *  - resolveLink: looks up claim metadata by claimId
 *
 * Production: integrate with a deployed USDCEscrow.sol contract.
 * Scaffold: uses localStorage-backed demo store so the UI is fully functional.
 */

import { useState, useCallback, useRef } from 'react'
import { encodeTransfer, ContractAddress } from '@circle-fin/modular-wallets-core'
import { parseUsdc, formatUsdc } from '@/onchain-money'
import { buildClaimUrl, generateClaimId } from '@/utils/claimUrl'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { checkDailyCap, recordSpend } from '@/utils/dailyCap'
import type { ClaimLink, TxState } from '@/types/wallet'
import type { PasskeyWalletState } from './usePasskeyWallet'

const ARC_TESTNET_ID = 5042002
const USDC_ADDRESS = ContractAddress.ArcTestnet_USDC
const ESCROW_STORE_KEY = 'flowpay:escrow'
const CLAIM_TTL_MS = 72 * 60 * 60 * 1000  // 72 hours

// ─── Simple localStorage escrow store (replace with contract calls in prod) ──

function readStore(): Record<string, ClaimLink> {
  try {
    const raw = localStorage.getItem(ESCROW_STORE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as Record<string, { amountRaw: string; senderAddress: string; senderName: string; status: string; expiresAt: number; url: string }>
      const result: Record<string, ClaimLink> = {}
      for (const [id, v] of Object.entries(parsed)) {
        result[id] = {
          claimId: id,
          senderAddress: v.senderAddress,
          senderName: v.senderName,
          amountUsdc: formatUsdc(BigInt(v.amountRaw)),
          amountRaw: BigInt(v.amountRaw),
          expiresAt: v.expiresAt,
          status: v.status as ClaimLink['status'],
          url: v.url,
        }
      }
      return result
    }
  } catch {
    // ignore
  }
  return {}
}

function writeStore(store: Record<string, ClaimLink>): void {
  const serializable: Record<string, unknown> = {}
  for (const [id, link] of Object.entries(store)) {
    serializable[id] = { ...link, amountRaw: link.amountRaw.toString() }
  }
  localStorage.setItem(ESCROW_STORE_KEY, JSON.stringify(serializable))
}

// ─── Hook ────────────────────────────────────────────────────────────────────

export interface CreateClaimResult {
  link: ClaimLink
  url: string
}

export interface ClaimLinkState {
  /** Pending claim detected in the URL on mount */
  pendingClaim: ClaimLink | null
  /** TxState for the active create or claim operation */
  txState: TxState
  createLink: (amountUsdc: string, senderName: string) => Promise<CreateClaimResult>
  claimLink: (claimId: string) => Promise<void>
  resolveLink: (claimId: string) => ClaimLink | null
  reset: () => void
}

export function useClaimLink(wallet: PasskeyWalletState): ClaimLinkState {
  const [txState, setTxState] = useState<TxState>({ stage: 'idle' })
  // Detect ?claim= param on mount via lazy initializer — no effect needed
  const [pendingClaim, setPendingClaim] = useState<ClaimLink | null>(() => {
    const params = new URLSearchParams(window.location.search)
    const claimId = params.get('claim')
    if (claimId) {
      const store = readStore()
      return store[claimId] ?? null
    }
    return null
  })

  // Stable ref so callbacks always read the current wallet without a stale closure.
  // Writing .current during render is intentional — it is never read during render.
  // oxlint-disable-next-line react/refs
  const walletRef = useRef(wallet)
  // oxlint-disable-next-line react/refs
  walletRef.current = wallet

  const reset = useCallback(() => setTxState({ stage: 'idle' }), [])

  // ── Create a new claim link ───────────────────────────────────────────────
  const createLink = useCallback(async (amountUsdc: string, senderName: string): Promise<CreateClaimResult> => {
    const { account, bundler, accountAddress } = walletRef.current
    if (account == null || bundler == null || !accountAddress) {
      throw new Error('Wallet not connected')
    }
    // oxlint-disable-next-line typescript/no-explicit-any
    const b = bundler as any
    // oxlint-disable-next-line typescript/no-explicit-any
    const a = account as any
    const amountRaw = parseUsdc(amountUsdc)

    // Cap check
    const capCheck = checkDailyCap(accountAddress, amountRaw)
    if (!capCheck.ok) throw new Error(capCheck.reason)

    setTxState({ stage: 'signing' })

    // In production: call escrow.lock(claimId, amount, expiresAt) via sendUserOperation
    // Scaffold: store the claim locally and simulate a gasless escrow lock
    const claimId = generateClaimId()
    const url = buildClaimUrl(claimId)
    const expiresAt = Date.now() + CLAIM_TTL_MS

    try {
      // Gasless user-op: transfer USDC to a simulated escrow address
      // In production replace with the real escrow contract call
      // BUG FIX: original address contained 'w' (not valid hex). Use a valid placeholder.
      const escrowAddress = '0xE5C2000000000000000000000000000000000001' as `0x${string}`
      const callData = encodeTransfer(escrowAddress, USDC_ADDRESS, amountRaw)

      const hash = await b.sendUserOperation({
        account: a,
        calls: [callData],
        paymaster: true,
      })

      setTxState({ stage: 'confirming' })
      const { receipt } = await b.waitForUserOperationReceipt({ hash })
      const explorerUrl = buildTxExplorerUrl(ARC_TESTNET_ID, receipt.transactionHash)

      recordSpend(accountAddress, amountRaw)

      const link: ClaimLink = {
        claimId,
        senderAddress: accountAddress,
        senderName,
        amountUsdc: formatUsdc(amountRaw),
        amountRaw,
        expiresAt,
        status: 'pending',
        url,
      }

      const store = readStore()
      store[claimId] = link
      writeStore(store)

      setTxState({ stage: 'success', txHash: receipt.transactionHash, explorerUrl })
      return { link, url }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to create link'
      setTxState({ stage: 'error', errorMessage: msg })
      throw err
    }
  }, []) // stable — reads wallet via walletRef

  // ── Claim USDC from an existing link ─────────────────────────────────────
  const claimLink = useCallback(async (claimId: string): Promise<void> => {
    const { account, bundler, accountAddress } = walletRef.current
    if (account == null || bundler == null || !accountAddress) {
      setTxState({ stage: 'error', errorMessage: 'Sign in first to claim your USDC.' })
      return
    }
    const b = bundler as any
    const a = account as any

    const store = readStore()
    const link = store[claimId]
    if (!link) {
      setTxState({ stage: 'error', errorMessage: 'Claim link not found or already used.' })
      return
    }
    if (link.status !== 'pending') {
      setTxState({ stage: 'error', errorMessage: `This link has already been ${link.status}.` })
      return
    }
    if (Date.now() > link.expiresAt) {
      setTxState({ stage: 'error', errorMessage: 'This claim link has expired.' })
      return
    }

    setTxState({ stage: 'signing' })

    // In production: call escrow.claim(claimId) via sendUserOperation
    // Scaffold: simulate a gasless claim (transfer from escrow to self)
    try {
      const callData = encodeTransfer(
        accountAddress as `0x${string}`,
        USDC_ADDRESS,
        0n, // In production, this is the escrow.claim() call
      )

      const hash = await b.sendUserOperation({
        account: a,
        calls: [callData],
        paymaster: true,
      })

      setTxState({ stage: 'confirming' })
      const { receipt } = await b.waitForUserOperationReceipt({ hash })
      const explorerUrl = buildTxExplorerUrl(ARC_TESTNET_ID, receipt.transactionHash)

      // Mark as claimed
      store[claimId] = { ...link, status: 'claimed' }
      writeStore(store)
      setPendingClaim(null)

      setTxState({ stage: 'success', txHash: receipt.transactionHash, explorerUrl })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Claim failed'
      setTxState({ stage: 'error', errorMessage: msg })
    }
  }, []) // stable — reads wallet via walletRef

  const resolveLink = useCallback((claimId: string): ClaimLink | null => {
    return readStore()[claimId] ?? null
  }, [])

  return { pendingClaim, txState, createLink, claimLink, resolveLink, reset }
}
