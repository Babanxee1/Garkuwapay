/**
 * useExternalSend
 *
 * USDC transfer for externally-connected wallets (MetaMask, Coinbase Wallet, etc.)
 * Uses wagmi writeContract — the wallet signs a standard ERC-20 transfer.
 * No gas abstraction; the user pays gas in the chain's native token.
 * On Arc Testnet the native token IS USDC, so this is still effectively gasless.
 */

import { useState, useCallback } from 'react'
import { useWriteContract, usePublicClient, useSwitchChain, useAccount } from 'wagmi'
import { isAddress, parseUnits } from 'viem'
import { arcTestnet } from 'viem/chains'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import type { TxState } from '@/types/wallet'
import type { SafeSendState, SendParams } from './useSafeSend'

const ARC_TESTNET_ID = 5042002
const usdcFact = getUsdc(ARC_TESTNET_ID)
const USDC_ADDRESS = usdcFact?.address as `0x${string}`
const USDC_DECIMALS = usdcFact?.decimals ?? 6

const ERC20_TRANSFER_ABI = [
  {
    name: 'transfer',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'to',     type: 'address' },
      { name: 'amount', type: 'uint256' },
    ],
    outputs: [{ name: '', type: 'bool' }],
  },
] as const

export function useExternalSend(): SafeSendState {
  const [txState, setTxState] = useState<TxState>({ stage: 'idle' })
  const { writeContractAsync } = useWriteContract()
  const publicClient = usePublicClient()
  const { switchChainAsync } = useSwitchChain()
  const { chainId } = useAccount()

  const reset = useCallback(() => setTxState({ stage: 'idle' }), [])

  const send = useCallback(async ({ to, amountUsdc }: SendParams): Promise<void> => {
    if (!isAddress(to)) {
      setTxState({ stage: 'error', errorMessage: 'Invalid recipient address.' })
      return
    }
    if (!USDC_ADDRESS) {
      setTxState({ stage: 'error', errorMessage: 'USDC address not found for Arc Testnet.' })
      return
    }

    try {
      // Switch to Arc Testnet if needed
      if (chainId !== ARC_TESTNET_ID) {
        setTxState({ stage: 'signing' })
        await switchChainAsync({ chainId: arcTestnet.id })
      }

      setTxState({ stage: 'signing' })
      const amount = parseUnits(amountUsdc, USDC_DECIMALS)

      const txHash = await writeContractAsync({
        address: USDC_ADDRESS,
        abi: ERC20_TRANSFER_ABI,
        functionName: 'transfer',
        args: [to, amount],
        chainId: arcTestnet.id,
      })

      setTxState({ stage: 'confirming' })

      // Wait for the transaction to be mined
      if (publicClient) {
        const receipt = await publicClient.waitForTransactionReceipt({ hash: txHash })
        if (receipt.status === 'reverted') {
          setTxState({ stage: 'error', errorMessage: 'Transaction reverted on-chain.' })
          return
        }
      }

      const explorerUrl = buildTxExplorerUrl(ARC_TESTNET_ID, txHash)
      setTxState({ stage: 'success', txHash, explorerUrl })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Transaction failed'
      // User rejection is not an error worth surfacing as a full error state
      if (msg.toLowerCase().includes('rejected') || msg.toLowerCase().includes('denied') || msg.toLowerCase().includes('cancelled')) {
        setTxState({ stage: 'idle' })
        return
      }
      setTxState({ stage: 'error', errorMessage: msg })
    }
  }, [writeContractAsync, publicClient, switchChainAsync, chainId])

  return { txState, send, reset }
}
