/**
 * useUsdcBalance
 *
 * Live ERC-20 USDC balance for a given address on Arc Testnet.
 * Polls every 8 seconds while the component is mounted.
 */

import { useState, useEffect, useCallback } from 'react'
import { createPublicClient, http } from 'viem'
import { arcTestnet } from 'viem/chains'
import { getUsdc, requireChain } from '@/onchain-facts'
import { formatUsdc } from '@/onchain-money'

const ARC_TESTNET_ID = 5042002
const usdcFact = getUsdc(ARC_TESTNET_ID)
const USDC_ADDRESS = usdcFact?.address as `0x${string}` | undefined

const ERC20_BALANCE_ABI = [
  {
    name: 'balanceOf',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
] as const

const publicClient = createPublicClient({
  chain: arcTestnet,
  transport: http(requireChain(ARC_TESTNET_ID).rpcUrls[0]),
})

export interface UsdcBalanceState {
  raw: bigint | null
  formatted: string | null
  loading: boolean
  error: string | null
  refetch: () => Promise<void>
}

export function useUsdcBalance(address: string | null): UsdcBalanceState {
  const [raw, setRaw] = useState<bigint | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchBalance = useCallback(async () => {
    if (!address || !USDC_ADDRESS) return
    setLoading(true)
    setError(null)
    try {
      const balance = await publicClient.readContract({
        address: USDC_ADDRESS,
        abi: ERC20_BALANCE_ABI,
        functionName: 'balanceOf',
        args: [address as `0x${string}`],
      })
      setRaw(balance)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch balance')
    } finally {
      setLoading(false)
    }
  }, [address])

  useEffect(() => {
    let active = true
    const run = () => { if (active) void fetchBalance() }
    run()
    const interval = setInterval(run, 8_000)
    return () => { active = false; clearInterval(interval) }
  }, [fetchBalance])

  return {
    raw,
    formatted: raw !== null ? formatUsdc(raw) : null,
    loading,
    error,
    refetch: fetchBalance,
  }
}
