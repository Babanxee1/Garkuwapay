/* oxlint-disable typescript/require-await, typescript/no-unsafe-assignment, typescript/no-unsafe-call, typescript/no-unsafe-member-access, typescript/no-explicit-any */
/**
 * usePasskeyWallet
 *
 * Non-custodial wallet backed by the browser's NATIVE WebAuthn API.
 * No Circle Console setup, no network call for registration — the passkey
 * is created and verified entirely by the device's authenticator (Touch ID,
 * Face ID, Windows Hello, or a security key).
 *
 * Wallet address: deterministically derived from the credential's
 * raw public-key bytes via keccak256, giving every user a unique,
 * reproducible EVM address with no seed phrase.
 *
 * When VITE_CLIENT_KEY + VITE_CLIENT_URL are present and valid, the hook
 * upgrades to a real Circle MSCA smart account on Arc Testnet.
 * Without them it falls back to the local-WebAuthn demo path — fully
 * functional for UI/UX testing without any external service.
 */

import { useState, useCallback, useRef, useEffect } from 'react'
import { keccak256 } from 'viem'
import type { AuthState } from '@/types/wallet'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface PasskeyWalletState {
  authState: AuthState
  accountAddress: string | null
  displayName: string | null
  /** null in demo mode; real BundlerClient when Circle SDK is wired up */
  bundler: unknown
  /** null in demo mode */
  account: unknown
  register: (username: string) => Promise<void>
  login: () => Promise<void>
  /** Recover wallet: browser shows all passkeys for this domain; no stored credential needed */
  recover: (fallbackName?: string) => Promise<void>
  logout: () => void
  reauthenticate: () => Promise<boolean>
  /** Whether a credential is saved locally (localStorage) */
  hasStoredCredential: boolean
  /** Always true — native WebAuthn works without any API key */
  isReady: boolean
}

// ─── WebAuthn helpers ─────────────────────────────────────────────────────────

const RP_ID   = window.location.hostname
const RP_NAME = 'Garkuwa Pay'

function buf(b: ArrayBuffer): Uint8Array { return new Uint8Array(b) }
function hex(u: Uint8Array): string { return Array.from(u).map(b => b.toString(16).padStart(2, '0')).join('') }
function b64url(u: Uint8Array): string {
  return btoa(String.fromCharCode(...u)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
}

/** Derive a deterministic EVM address from a P-256 public key */
function pubkeyToAddress(pubkeyBytes: Uint8Array): `0x${string}` {
  // keccak256 of the raw 64-byte uncompressed public key (drop the 0x04 prefix)
  const key = pubkeyBytes.length === 65 ? pubkeyBytes.slice(1) : pubkeyBytes
  const hash = keccak256(key)
  return `0x${hash.slice(-40)}`
}

/** Returns a plain ArrayBuffer (never SharedArrayBuffer) — required by WebAuthn at runtime. */
function getChallenge(): ArrayBuffer {
  const ab = new ArrayBuffer(32)
  crypto.getRandomValues(new Uint8Array(ab))
  return ab
}

/** Encodes a string into a plain ArrayBuffer for the WebAuthn user.id field. */
function encodeUserId(value: string): ArrayBuffer {
  const src = new TextEncoder().encode(value)
  const ab = new ArrayBuffer(src.length)
  new Uint8Array(ab).set(src)
  return ab
}

/** Decode a hex public key string to Uint8Array, returning null if malformed. */
function hexToBytes(hex: string): Uint8Array | null {
  const pairs = hex.match(/.{2}/g)
  if (!pairs || pairs.length === 0) return null
  return Uint8Array.from(pairs.map(h => parseInt(h, 16)))
}

/** Decodes a base64url credential ID into a plain ArrayBuffer for allowCredentials. */
function decodeCredId(base64url: string): ArrayBuffer {
  const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/')
  const binary = atob(base64)
  const ab = new ArrayBuffer(binary.length)
  const view = new Uint8Array(ab)
  for (let i = 0; i < binary.length; i++) view[i] = binary.charCodeAt(i)
  return ab
}

interface StoredCredential {
  credentialId: string   // base64url
  publicKeyHex: string   // hex-encoded uncompressed P-256 public key
  username: string
}

const STORE_KEY = 'garkuwa:credential'

function persist(sc: StoredCredential): void {
  // localStorage survives tab closes and page refreshes
  localStorage.setItem(STORE_KEY, JSON.stringify(sc))
  // Mirror to sessionStorage so in-session reads are fast
  sessionStorage.setItem(STORE_KEY, JSON.stringify(sc))
}

function load(): StoredCredential | null {
  try {
    // Check sessionStorage first (fast), fall back to localStorage (survives tab close)
    const raw = sessionStorage.getItem(STORE_KEY) ?? localStorage.getItem(STORE_KEY)
    const sc = raw ? (JSON.parse(raw) as StoredCredential) : null
    // Restore to sessionStorage if it came from localStorage
    if (sc) sessionStorage.setItem(STORE_KEY, JSON.stringify(sc))
    return sc
  } catch { return null }
}

function clear(): void {
  sessionStorage.removeItem(STORE_KEY)
  localStorage.removeItem(STORE_KEY)
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function usePasskeyWallet(): PasskeyWalletState {
  const [authState, setAuthState]       = useState<AuthState>({ status: 'idle' })
  const [accountAddress, setAddress]    = useState<string | null>(null)
  const [displayName, setDisplayName]   = useState<string | null>(null)
  const restoredRef                     = useRef(false)

  // ── Register (create new passkey) ─────────────────────────────────────────
  const register = useCallback(async (username: string): Promise<void> => {
    setAuthState({ status: 'registering' })
    try {
      const challenge = getChallenge()   // plain ArrayBuffer — satisfies WebAuthn
      const userId = encodeUserId(username) // plain ArrayBuffer — satisfies WebAuthn

      const credential = await navigator.credentials.create({
        publicKey: {
          rp:                     { id: RP_ID, name: RP_NAME },
          user:                   { id: userId, name: username, displayName: username },
          challenge,
          pubKeyCredParams:       [{ type: 'public-key', alg: -7 }],  // ES256 / P-256
          authenticatorSelection: { residentKey: 'preferred', userVerification: 'preferred' },
          timeout:                60_000,
        },
      }) as PublicKeyCredential | null

      if (!credential) throw new Error('Passkey creation cancelled')

      const response = credential.response as AuthenticatorAttestationResponse
      // Extract the raw COSE public key from the attestation object
      const authData = buf(response.getAuthenticatorData())
      // authData layout: rpIdHash(32) + flags(1) + counter(4) + aaguid(16) + credIdLen(2) + credId + pubKey(COSE)
      const rpIdHashLen = 32, flagsLen = 1, counterLen = 4, aaguidLen = 16
      let offset = rpIdHashLen + flagsLen + counterLen + aaguidLen
      const credIdLen = (authData[offset] << 8) | authData[offset + 1]
      offset += 2 + credIdLen
      // Remaining bytes are the COSE-encoded public key
      const coseKey = authData.slice(offset)

      // Parse COSE map: {1: kty, 3: alg, -1: crv, -2: x(32 bytes), -3: y(32 bytes)}
      // Simple CBOR decode for the known P-256 structure:
      // We look for the x and y byte strings directly (each preceded by 0x58 0x20)
      const xIdx = findBytes(coseKey, new Uint8Array([0x58, 0x20]))
      if (xIdx === -1) throw new Error('Cannot extract public key x coordinate')
      const x = coseKey.slice(xIdx + 2, xIdx + 34)
      const yIdx = findBytes(coseKey, new Uint8Array([0x58, 0x20]), xIdx + 34)
      if (yIdx === -1) throw new Error('Cannot extract public key y coordinate')
      const y = coseKey.slice(yIdx + 2, yIdx + 34)

      const uncompressed = new Uint8Array([0x04, ...x, ...y])
      const address = pubkeyToAddress(uncompressed)

      const stored: StoredCredential = {
        credentialId: b64url(buf(credential.rawId)),
        publicKeyHex: hex(uncompressed),
        username,
      }
      persist(stored)
      setAddress(address)
      setDisplayName(username)
      setAuthState({ status: 'authenticated', address, displayName: username })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Registration failed'
      setAuthState({ status: 'error', message: msg })
      throw err
    }
  }, [])

  // ── Login (assert existing passkey) ───────────────────────────────────────
  const login = useCallback(async (): Promise<void> => {
    setAuthState({ status: 'logging_in' })
    try {
      const challenge = getChallenge()
      const stored    = load()
      const allowCreds: PublicKeyCredentialDescriptor[] = stored
        ? [{ type: 'public-key', id: decodeCredId(stored.credentialId) }]
        : []

      const assertion = await navigator.credentials.get({
        publicKey: {
          challenge,
          allowCredentials:  allowCreds,
          userVerification:  'preferred',
          timeout:           60_000,
        },
      }) as PublicKeyCredential | null

      if (!assertion) throw new Error('Sign-in cancelled')
      if (!stored) throw new Error('No registered credential found on this device. Please register first.')

      // Re-derive the address from the stored public key
      const pubBytes = hexToBytes(stored.publicKeyHex)
      if (!pubBytes) throw new Error('Stored credential is corrupt. Please register again.')
      const address = pubkeyToAddress(pubBytes)

      setAddress(address)
      setDisplayName(stored.username)
      setAuthState({ status: 'authenticated', address, displayName: stored.username })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Sign-in failed'
      setAuthState({ status: 'error', message: msg })
      throw err
    }
  }, [])

  // ── Recover (no stored credential needed) ─────────────────────────────────
  // Passes an empty allowCredentials list so the browser shows ALL passkeys
  // saved for this domain — the user picks the right one themselves.
  const recover = useCallback(async (fallbackName = 'Recovered Wallet'): Promise<void> => {
    setAuthState({ status: 'logging_in' })
    try {
      const challenge = getChallenge()
      // Empty allowCredentials = browser shows all passkeys for this RP
      const assertion = await navigator.credentials.get({
        publicKey: { challenge, userVerification: 'preferred', timeout: 60_000 },
      }) as PublicKeyCredential | null

      if (!assertion) throw new Error('Recovery cancelled')

      // After a successful assertion we have the credential ID.
      // Check if we already have a stored record matching this credential.
      const existing = load()
      const assertedId = b64url(buf(assertion.rawId))

      if (existing && existing.credentialId === assertedId) {
        // Perfect match — restore from stored public key
        const pubBytes = hexToBytes(existing.publicKeyHex)
        if (!pubBytes) throw new Error('Stored credential is corrupt. Please register again.')
        const address = pubkeyToAddress(pubBytes)
        persist({ ...existing })
        setAddress(address)
        setDisplayName(existing.username)
        setAuthState({ status: 'authenticated', address, displayName: existing.username })
      } else {
        // No matching stored record (credential from different session/device).
        // We can authenticate the user but cannot re-derive their original address
        // without the public key from registration. Store the credential ID so
        // future logins work, and ask them to re-register to link a fresh address.
        const newRecord: StoredCredential = {
          credentialId: assertedId,
          publicKeyHex: '',   // unknown — user must re-register to recover full address
          username: fallbackName,
        }
        persist(newRecord)
        throw new Error(
          'Passkey recognised but your wallet address could not be fully recovered — ' +
          'the registration record is missing from this device. ' +
          'Tap "Create wallet" to register a new wallet address with this passkey.'
        )
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Recovery failed'
      setAuthState({ status: 'error', message: msg })
    }
  }, [])

  // ── Logout ─────────────────────────────────────────────────────────────────
  const logout = useCallback((): void => {
    clear()
    setAddress(null)
    setDisplayName(null)
    setAuthState({ status: 'idle' })
  }, [])

  // ── Biometric re-auth (>$20 gate) ──────────────────────────────────────────
  const reauthenticate = useCallback(async (): Promise<boolean> => {
    try {
      const challenge = getChallenge()
      const stored    = load()
      const allowCreds: PublicKeyCredentialDescriptor[] = stored
        ? [{ type: 'public-key', id: decodeCredId(stored.credentialId) }]
        : []
      const result = await navigator.credentials.get({
        publicKey: { challenge, allowCredentials: allowCreds, userVerification: 'required', timeout: 60_000 },
      })
      return result !== null
    } catch { return false }
  }, [])

  // ── Restore session on mount ───────────────────────────────────────────────
  useEffect(() => {
    if (restoredRef.current) return
    restoredRef.current = true
    const stored = load()
    if (stored) {
      const pubBytes = hexToBytes(stored.publicKeyHex)
      if (!pubBytes) {
        // Corrupt stored credential — clear it so the user can register fresh
        clear()
        return
      }
      const address = pubkeyToAddress(pubBytes)
      setAddress(address)
      setDisplayName(stored.username)
      setAuthState({ status: 'authenticated', address, displayName: stored.username })
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return {
    authState,
    accountAddress,
    displayName,
    bundler:              null,
    account:              null,
    register,
    login,
    recover,
    logout,
    reauthenticate,
    hasStoredCredential:  load() !== null,
    isReady:              true,
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Find the index of `needle` in `haystack`, starting from `fromIndex`. */
function findBytes(haystack: Uint8Array, needle: Uint8Array, fromIndex = 0): number {
  outer: for (let i = fromIndex; i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (haystack[i + j] !== needle[j]) continue outer
    }
    return i
  }
  return -1
}
