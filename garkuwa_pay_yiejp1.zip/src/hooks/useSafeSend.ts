/* oxlint-disable typescript/no-unsafe-assignment, typescript/no-unsafe-call, typescript/no-unsafe-member-access, typescript/no-unsafe-argument, typescript/no-explicit-any */
/**
 * useSafeSend
 *
 * Gasless USDC send with Safe-Mode enforcement, daily cap tracking, and
 * biometric re-authentication gate for amounts above $20 USDC.
 *
 * Flow:
 *  1. Validate amount against daily cap
 *  2. If amount >= $20 USDC, trigger passkey re-auth
 *  3. Assert Safe-Mode call compliance
 *  4. sendUserOperation with paymaster: true (Circle Gas Station)
 *  5. waitForUserOperationReceipt
 *  6. Record spend against daily cap
 */

import { useState, useCallback, useRef } from 'react'
import { type Hex } from 'viem'
import { encodeTransfer, ContractAddress } from '@circle-fin/modular-wallets-core'
import { parseUsdc } from '@/onchain-money'
import { buildTxExplorerUrl } from '@/onchain-facts'
import { assertSafeCall, SafeModeError } from '@/utils/safeMode'
import { checkDailyCap, requiresBiometric, recordSpend } from '@/utils/dailyCap'
import type { TxState } from '@/types/wallet'
import type { PasskeyWalletState } from './usePasskeyWallet'

const ARC_TESTNET_ID = 5042002
const USDC_ADDRESS = ContractAddress.ArcTestnet_USDC

export interface SendParams {
  to: string
  amountUsdc: string   // human-readable, e.g. "5.00"
}

export interface SafeSendState {
  txState: TxState
  send: (params: SendParams) => Promise<void>
  reset: () => void
}

export function useSafeSend(wallet: PasskeyWalletState): SafeSendState {
  const [txState, setTxState] = useState<TxState>({ stage: 'idle' })

  // Stable ref so `send` always reads the current wallet without being recreated on
  // every render. Writing .current during render is intentional — never read during render.
  // oxlint-disable-next-line react/refs
  const walletRef = useRef(wallet)
  // oxlint-disable-next-line react/refs
  walletRef.current = wallet

  const reset = useCallback(() => setTxState({ stage: 'idle' }), [])

  const send = useCallback(async ({ to, amountUsdc }: SendParams): Promise<void> => {
    // Read current values via ref — always fresh, no stale-closure risk
    const { account, bundler, accountAddress, reauthenticate } = walletRef.current

    if (account == null || bundler == null || !accountAddress) {
      setTxState({ stage: 'error', errorMessage: 'Wallet not connected. Please sign in first.' })
      return
    }
    // bundler/account are `unknown` in demo mode; cast for runtime use.
    // In production with Circle SDK they carry the real BundlerClient / SmartAccount types.
    // oxlint-disable-next-line typescript/no-explicit-any
    const b = bundler as any
    // oxlint-disable-next-line typescript/no-explicit-any
    const a = account as any

    const amountRaw = parseUsdc(amountUsdc)

    // ── 1. Daily cap check ────────────────────────────────────────────────
    const capCheck = checkDailyCap(accountAddress, amountRaw)
    if (!capCheck.ok) {
      setTxState({ stage: 'error', errorMessage: capCheck.reason })
      return
    }

    // ── 2. Biometric re-auth gate (>= $20 USDC) ───────────────────────────
    if (requiresBiometric(amountRaw)) {
      setTxState({ stage: 'biometric' })
      const ok = await reauthenticate()
      if (!ok) {
        setTxState({ stage: 'error', errorMessage: 'Biometric authentication failed. Transaction cancelled.' })
        return
      }
    }

    // ── 3. Encode transfer calldata ────────────────────────────────────────
    const callData = encodeTransfer(to as Hex, USDC_ADDRESS, amountRaw)

    // ── 4. Safe-Mode guard ────────────────────────────────────────────────
    const callDataObj = callData as { to?: string; data?: Hex; value?: bigint }
    try {
      assertSafeCall({ to: USDC_ADDRESS, data: callDataObj.data ?? '0x' }, ARC_TESTNET_ID)
    } catch (err) {
      if (err instanceof SafeModeError) {
        setTxState({ stage: 'error', errorMessage: `Safe Mode: ${err.violation.description}` })
        return
      }
      throw err
    }

    // ── 5. Send user operation (gasless) ──────────────────────────────────
    setTxState({ stage: 'signing' })
    try {
      const hash = await b.sendUserOperation({
        account: a,
        calls: [callData],
        paymaster: true,
      })

      // ── 6. Wait for receipt ───────────────────────────────────────────
      setTxState({ stage: 'confirming' })
      const { receipt } = await b.waitForUserOperationReceipt({ hash })
      const explorerUrl = buildTxExplorerUrl(ARC_TESTNET_ID, receipt.transactionHash)

      // ── 7. Record spend ───────────────────────────────────────────────
      recordSpend(accountAddress, amountRaw)

      setTxState({
        stage: 'success',
        txHash: receipt.transactionHash,
        explorerUrl,
      })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Transaction failed'
      setTxState({ stage: 'error', errorMessage: message })
    }
  }, []) // stable — reads wallet via ref, not closure

  return { txState, send, reset }
}
