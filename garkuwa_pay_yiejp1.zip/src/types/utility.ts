// ─── Utility & Off-Ramp Types ─────────────────────────────────────────────────

export type UtilityCategory = 'airtime' | 'data' | 'electricity' | 'water'

export interface UtilityProduct {
  id: string
  name: string
  category: UtilityCategory
  description: string
  minUsdcAmount: number
  maxUsdcAmount: number
  logoUrl?: string
  /** Country ISO code the product is available in */
  country: string
}

export interface UtilityPurchaseResult {
  referenceId: string
  productId: string
  amountUsdc: string
  status: 'pending' | 'success' | 'failed'
  receipt?: string
}

export interface OfframpQuote {
  provider: string           // "MoonPay" | "Transak"
  usdcAmount: string
  localAmount: string
  localCurrency: string
  fee: string
  estimatedArrival: string   // "1-2 business days"
  paymentMethod: string
}

export interface OfframpInitiation {
  orderId: string
  redirectUrl: string
  provider: string
  status: 'initiated'
}
