// ─── Wallet & Auth Types ─────────────────────────────────────────────────────

export type AuthState =
  | { status: 'idle' }
  | { status: 'registering' }
  | { status: 'logging_in' }
  | { status: 'authenticated'; address: string; displayName?: string }
  | { status: 'error'; message: string }

export type TxStage =
  | 'idle'
  | 'biometric'        // Waiting for passkey re-auth
  | 'signing'          // sendUserOperation in progress
  | 'confirming'       // waitForUserOperationReceipt in progress
  | 'success'
  | 'error'

export interface TxState {
  stage: TxStage
  txHash?: string
  explorerUrl?: string
  errorMessage?: string
}

// ─── Safe-Mode Types ──────────────────────────────────────────────────────────

export type SafeModeBlock =
  | 'eth_sign'
  | 'open_allowance'
  | 'non_usdc_contract'
  | 'daily_cap_exceeded'

export interface SafeModeViolation {
  block: SafeModeBlock
  description: string
}

// ─── Claim Link Types ─────────────────────────────────────────────────────────

export type ClaimStatus = 'pending' | 'claimed' | 'expired' | 'refunded'

export interface ClaimLink {
  claimId: string
  senderAddress: string
  senderName: string
  amountUsdc: string       // human-readable, e.g. "5.00"
  amountRaw: bigint        // ERC-20 units (6 decimals)
  expiresAt: number        // Unix timestamp (ms)
  status: ClaimStatus
  url: string
}

export interface CreateClaimParams {
  amountUsdc: string
  senderName: string
  recipientHint?: string   // optional address or ENS hint
}

// ─── Daily Spending Cap ───────────────────────────────────────────────────────

export interface DailySpend {
  dateUtc: string      // "YYYY-MM-DD"
  spentRaw: bigint     // cumulative in ERC-20 USDC units
}

export const DAILY_CAP_USDC = 50    // USD
export const BIOMETRIC_GATE_USDC = 20  // USD — re-auth required above this
