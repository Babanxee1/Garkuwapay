# Garkuwa Pay — Architecture & Technical Blueprint

## 1. Product Vision

A beginner-friendly, non-custodial, gasless USDC wallet built for viral sharing via Facebook Messenger and mobile web. Zero gas fees, biometric authentication, and single-tap claim links that render as rich OG cards in Messenger.

---

## 2. System Architecture Diagram (ASCII)

```
┌──────────────────────────────────────────────────────────────────┐
│                         BROWSER / PWA                            │
│  ┌─────────────────┐  ┌──────────────────┐  ┌───────────────┐   │
│  │  Auth Layer     │  │  Wallet Layer     │  │  UI Layer     │   │
│  │  Facebook OAuth │  │  Circle Modular  │  │  React + TW   │   │
│  │  (Privy/Auth0)  │  │  Wallet (MSCA)   │  │  Framer Mot.  │   │
│  │  Passkey WebAuth│  │  ERC-4337 + AA   │  │  Arc Light    │   │
│  └────────┬────────┘  └────────┬─────────┘  └───────────────┘   │
│           │                    │                                  │
│  ┌────────▼────────────────────▼─────────────────────────────┐   │
│  │               Safe-Mode Account Guard                     │   │
│  │  • Whitelist: USDC transfer / approve only                │   │
│  │  • Block: eth_sign, open allowances, arbitrary calls      │   │
│  │  • Daily cap: $50 USDC · Re-auth gate: >$20 USDC         │   │
│  └───────────────────────────────────────────────────────────┘   │
└──────────────────────────────────┬───────────────────────────────┘
                                   │ HTTPS
┌──────────────────────────────────▼───────────────────────────────┐
│                         BACKEND / API                             │
│  ┌────────────────────┐  ┌───────────────────┐                   │
│  │  Express / Next.js │  │  OG Image Service │                   │
│  │  /api/claim/*      │  │  (Canvas/Satori)  │                   │
│  │  /api/utility/*    │  │  /api/og/:claimId │                   │
│  │  /api/offramp/*    │  └───────────────────┘                   │
│  └────────────────────┘                                          │
└──────────────────────────────────┬───────────────────────────────┘
                                   │
┌──────────────────────────────────▼───────────────────────────────┐
│                       BLOCKCHAIN LAYER                            │
│  Arc Testnet (USDC native gas) — Chain ID 5042002                │
│  ┌──────────────────┐  ┌────────────────────┐                    │
│  │  USDCEscrow.sol  │  │  Circle Gas Station│                    │
│  │  Lock, Claim,    │  │  (Paymaster)       │                    │
│  │  Expire, Refund  │  │  paymaster: true   │                    │
│  └──────────────────┘  └────────────────────┘                    │
└──────────────────────────────────────────────────────────────────┘
```

---

## 3. Technical Stack

### Frontend
| Layer | Technology | Reason |
|-------|-----------|--------|
| Framework | React 18 + TypeScript + Vite | Pre-scaffolded; fast HMR |
| Styling | Tailwind CSS v3 + Arc Light tokens | Consistent money-app aesthetic |
| Animation | Framer Motion | Springs, sheets, CTA states |
| Wallet SDK | `@circle-fin/modular-wallets-core` | Circle MSCA + passkey + Gas Station |
| Wagmi | `wagmi` v2 + `viem` | Chain reads, contract calls |
| Icons | `lucide-react` + `@web3icons/react` | No emoji |

### Smart Accounts (Account Abstraction)
| Feature | Implementation |
|---------|---------------|
| Account type | Circle MSCA (ERC-4337 + ERC-6900) |
| Passkey auth | `toWebAuthnCredential` + `toWebAuthnAccount` |
| Gas sponsorship | Circle Gas Station (`paymaster: true`) |
| Safe-mode guard | Client-side call filter before `sendUserOperation` |
| Daily cap tracking | `localStorage` counter reset at midnight UTC |

### Escrow System
| Feature | Implementation |
|---------|---------------|
| Lock USDC | `USDCEscrow.sol` — lock amount + expiry + claimant hash |
| Claim URL | `https://pay.yourdomain.com/claim/[claimId]` |
| OG metadata | Express `/api/og/:claimId` — HTML with `<meta>` tags |
| OG image | `canvas` or `@vercel/og` rendering claim amount banner |
| Expiry/refund | 72h default, callable `expire()` returns funds to sender |

### Backend (Express, runs alongside Vite)
| Route | Purpose |
|-------|---------|
| `GET /api/claim/:id` | Return claim metadata (amount, sender name, status) |
| `GET /api/og/:id` | Return HTML page with OG meta + redirect to app |
| `POST /api/utility/airtime` | Proxy to Reloadly for airtime top-up |
| `GET /api/utility/products` | List available utility products for user's region |
| `POST /api/offramp/initiate` | Initiate off-ramp (MoonPay/Transak stub) |

### PWA & WebView Optimization
- `manifest.json`: standalone display mode, theme-color, icons
- Service worker: cache app shell for offline/slow connections
- Viewport: `maximum-scale=1` prevents Facebook WebView zoom quirks
- OG tags: `fb:app_id`, `og:image` must be absolute HTTPS URL

---

## 4. Directory Structure (Vite + React)

```
src/
  App.tsx                     ← Thin composition root
  main.tsx                    ← Providers (wagmi, ConnectKit, QueryClient)
  config.ts                   ← wagmi chain config
  index.css                   ← Arc Light tokens + fonts
  onchain-facts.ts            ← Chain/USDC facts (generated)
  onchain-money.ts            ← parseUsdc / formatUsdc (generated)
  onchain-wait.ts             ← Tx state machine (generated)

  types/
    wallet.ts                 ← SafeModeContext, ClaimLink, TxState
    utility.ts                ← UtilityProduct, OfframpQuote

  hooks/
    usePasskeyWallet.ts       ← Circle MSCA: register, login, account, bundler
    useUsdcBalance.ts         ← Live ERC-20 USDC balance
    useSafeSend.ts            ← Gasless send with safe-mode guard + daily cap
    useClaimLink.ts           ← Create escrow link + claim from link
    useDailySpendingCap.ts    ← $50/day tracker, biometric re-auth gate

  components/
    WalletShell.tsx           ← App chrome: header, nav tabs, background
    HeroBalance.tsx           ← Big USDC number + account address
    ActionRow.tsx             ← Send / Claim / Share / Utilities buttons
    SendSheet.tsx             ← Bottom sheet: gasless USDC send
    ClaimSheet.tsx            ← Bottom sheet: claim from escrow link
    ShareSheet.tsx            ← Create claim link + copy OG URL
    UtilityPanel.tsx          ← Airtime / data / bills purchase
    OfframpPanel.tsx          ← Fiat off-ramp initiation
    AuthGate.tsx              ← Passkey register/login screen
    SafeModeAlert.tsx         ← Blocked call warning overlay
    TxStatus.tsx              ← Inline Pending / Confirmed / Failed states

  utils/
    safeMode.ts               ← Call filter: whitelist + block list
    dailyCap.ts               ← Spend tracker with midnight UTC reset
    claimUrl.ts               ← Build / parse claim URLs
    ogMeta.ts                 ← OG meta helpers (sender name, amount)

contracts/
  USDCEscrow.sol              ← Lock → Claim → Expire escrow

server/                       ← Express backend (port 3001)
  index.ts
  routes/claim.ts
  routes/og.ts
  routes/utility.ts
  routes/offramp.ts
```

---

## 5. Authentication Flow

```
User opens app
  → AuthGate.tsx shows "Sign in with Facebook"
  → OAuth redirect → Facebook token returned
  → Server validates token, creates session
  → Client: toWebAuthnCredential({ mode: Register }) → Touch ID / Face ID
  → Credential persisted (httpOnly cookie in production)
  → toCircleSmartAccount(credential) → deterministic MSCA address
  → Hero balance loads from USDC ERC-20 balanceOf(account.address)
```

Note: Facebook OAuth requires a server-side OAuth callback route. In this scaffold, `AuthGate.tsx` simulates the auth gate UI and shows the passkey flow. Wire a real OAuth provider (Privy, Dynamic, or Auth0) for production.

---

## 6. Safe-Mode Rules

| Operation | Allowed |
|-----------|---------|
| USDC `transfer(to, amount)` | YES |
| USDC `approve(spender, amount)` where spender is known | YES (with cap) |
| Amount > $20 USDC | Biometric re-authentication required |
| Daily total > $50 USDC | Blocked with modal |
| `eth_sign` | BLOCKED |
| Open ERC-20 allowance (unlimited approve) | BLOCKED |
| Any non-USDC contract call | BLOCKED |
| `eth_sendTransaction` to unknown contract | BLOCKED |

---

## 7. OG Claim Link Flow

```
Sender locks 5 USDC → escrow contract
  → claimId generated (bytes32 UUID)
  → App builds URL: https://pay.yourdomain.com/claim/<claimId>
  → URL shared to Facebook Messenger

Messenger crawls URL
  → GET /api/og/<claimId>
  → Server responds: HTML with og:title, og:description, og:image
  → og:image = /api/og/<claimId>/image.png (dynamic canvas render)
  → Messenger shows rich card: "Alice sent you $5.00 USDC"

Recipient taps card
  → App opens, passkey login, MSCA created
  → ClaimSheet shows "Claim $5.00 USDC from Alice"
  → User taps Claim → gasless userOp calls escrow.claim(claimId)
  → USDC lands in recipient's MSCA
```

---

## 8. Console Setup Checklist (Circle Modular Wallets)

Before the passkey wallet works in the Arc Studio preview:

1. Go to [console.circle.com](https://console.circle.com) (Testnet mode).
2. **Keys → Client Keys → Create a key** (Client Key type).
3. Under **Applicable Platforms → Web**, set **Allowed Domain** to: `i8hys8icyszmvy8nrykkd.preview.studio.arc.io`
4. Copy the key (shown once, starts with `TEST_CLIENT_KEY:`), paste into `VITE_CLIENT_KEY` in `.env`.
5. **Wallets → Modular Wallets → Configurator → Passkeys → Domain Name**: set to the **same** hostname: `i8hys8icyszmvy8nrykkd.preview.studio.arc.io`
6. Save `.env`, restart the dev server, reload the preview, then test passkey registration inside the preview iframe.

Do **not** use `localhost` or `studio.arc.io` — Circle requires an exact match to the preview iframe origin.
