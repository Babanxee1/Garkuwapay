# Dynamic OpenGraph SSR Implementation

When a claim link is pasted into Facebook Messenger, Facebook's crawler GETs the URL
and reads `<meta>` tags. This server route returns a minimal HTML page with the correct
OG tags and a JavaScript redirect to the app.

---

## Express Route: `/api/og/:claimId`

Add this to your Express backend (`server/routes/og.ts`):

```typescript
import express from 'express'
import type { Request, Response } from 'express'

const router = express.Router()

// In production: resolve claim metadata from your database or on-chain
async function resolveClaimMeta(claimId: string) {
  // Replace with real DB / contract read
  return {
    senderName: 'Alice',
    amountUsdc: '5.00',
    status: 'pending' as const,
    appUrl: `${process.env.APP_BASE_URL}?claim=${claimId}`,
    imageUrl: `${process.env.APP_BASE_URL}/api/og/${claimId}/image.png`,
  }
}

router.get('/og/:claimId', async (req: Request, res: Response) => {
  const { claimId } = req.params
  const meta = await resolveClaimMeta(claimId)

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- OpenGraph — Facebook / Messenger -->
  <meta property="og:type" content="website" />
  <meta property="og:url" content="${meta.appUrl}" />
  <meta property="og:title" content="${meta.senderName} sent you $${meta.amountUsdc} USDC" />
  <meta property="og:description" content="Tap to claim your digital cash directly inside Messenger. No crypto experience needed." />
  <meta property="og:image" content="${meta.imageUrl}" />
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />

  <!-- Twitter Card (optional) -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${meta.senderName} sent you $${meta.amountUsdc} USDC" />
  <meta name="twitter:image" content="${meta.imageUrl}" />

  <!-- Facebook App ID (required for Messenger rich cards) -->
  <meta property="fb:app_id" content="${process.env.FB_APP_ID ?? ''}" />

  <title>${meta.senderName} sent you $${meta.amountUsdc} USDC</title>

  <!-- Redirect to the React app immediately -->
  <script>window.location.replace("${meta.appUrl}")</script>
</head>
<body>
  <noscript>
    <a href="${meta.appUrl}">Claim $${meta.amountUsdc} USDC from ${meta.senderName}</a>
  </noscript>
</body>
</html>`

  res.setHeader('Content-Type', 'text/html')
  // Cache for 30s — short because status can change (claimed/expired)
  res.setHeader('Cache-Control', 'public, max-age=30')
  res.send(html)
})

export default router
```

---

## Dynamic OG Image: `/api/og/:claimId/image.png`

Use `@vercel/og` (on Vercel/Next.js) or `canvas` (on Express) to generate a
1200×630 PNG banner at request time.

```typescript
// server/routes/ogImage.ts (canvas-based, no external deps beyond `canvas`)
import { createCanvas } from 'canvas'
import express from 'express'

const router = express.Router()

router.get('/og/:claimId/image.png', async (req, res) => {
  const { claimId } = req.params
  // Resolve from DB / contract
  const { senderName, amountUsdc } = await resolveClaimMeta(claimId)

  const width = 1200, height = 630
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  // Background
  ctx.fillStyle = '#122d45'
  ctx.fillRect(0, 0, width, height)

  // Subtle grid overlay
  ctx.strokeStyle = 'rgba(255,255,255,0.04)'
  for (let x = 0; x < width; x += 60) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke()
  }

  // Amount
  ctx.fillStyle = '#ffffff'
  ctx.font = 'bold 96px "Space Grotesk", sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText(`$${amountUsdc}`, width / 2, 300)

  // Label
  ctx.fillStyle = 'rgba(255,255,255,0.7)'
  ctx.font = '36px "DM Sans", sans-serif'
  ctx.fillText(`${senderName} sent you USDC`, width / 2, 380)

  // CTA
  ctx.fillStyle = 'rgba(255,255,255,0.4)'
  ctx.font = '28px "DM Sans", sans-serif'
  ctx.fillText('Tap to claim • Zero gas fees • Instant', width / 2, 460)

  const buffer = canvas.toBuffer('image/png')
  res.setHeader('Content-Type', 'image/png')
  res.setHeader('Cache-Control', 'public, max-age=300')
  res.send(buffer)
})

export default router
```

---

## Facebook WebView Optimization

Add to `index.html` for smooth loading inside Facebook's in-app browser:

```html
<!-- Prevent double-tap zoom in Facebook WebView -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1" />

<!-- Tell iOS to use a dark status bar if needed -->
<meta name="apple-mobile-web-app-status-bar-style" content="default" />

<!-- Facebook App ID — required for Messenger share attribution -->
<meta property="fb:app_id" content="YOUR_FB_APP_ID" />
```

Facebook's crawler ignores `<script>` redirects — it reads only `<meta>` tags.
Non-FB clients (iOS, Android, direct browser) hit the JS redirect instantly.

---

## PWA Manifest (`public/manifest.json`)

```json
{
  "name": "Garkuwa Pay",
  "short_name": "Garkuwa Pay",
  "description": "Send and claim USDC via Messenger",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#f9f9fc",
  "theme_color": "#122d45",
  "icons": [
    { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png" }
  ]
}
```

---

## Off-Ramp Stub (`/api/offramp`)

```typescript
// server/routes/offramp.ts
// Replace with MoonPay / Transak SDK for production

router.get('/offramp/quote', async (req, res) => {
  const { amount, currency } = req.query
  // Call MoonPay: GET /v3/currencies/quote?baseCurrencyAmount=...
  res.json({
    provider: 'MoonPay',
    usdcAmount: amount,
    localAmount: String(parseFloat(amount as string) * 0.97),
    localCurrency: currency ?? 'USD',
    fee: '3%',
    estimatedArrival: '1-2 business days',
    paymentMethod: 'Bank transfer / Mobile money',
  })
})

router.post('/offramp/initiate', async (req, res) => {
  const { amount, walletAddress, currency } = req.body
  // Redirect user to MoonPay widget URL or return Transak widget URL
  const widgetUrl = `https://buy.moonpay.com?apiKey=${process.env.MOONPAY_API_KEY}&walletAddress=${walletAddress}&baseCurrencyAmount=${amount}&defaultCurrencyCode=usdc`
  res.json({ orderId: 'demo-' + Date.now(), redirectUrl: widgetUrl, provider: 'MoonPay', status: 'initiated' })
})
```
